import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Input, r as Select, t as Field } from "./input-BZ_a7Ma_.mjs";
import { a as SCHEMES, i as RELATIONSHIPS, n as GENDERS, o as SETTLEMENTS, r as PROFESSIONS, s as SLIDING_SCALES, t as AM } from "./lookups-ClUJLUOS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/member-fields-CMf6vECy.js
var import_jsx_runtime = require_jsx_runtime();
function DateFields({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-3 gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				inputMode: "numeric",
				placeholder: "DD",
				value: value.day ?? "",
				onChange: (e) => onChange({
					...value,
					day: toInt(e.target.value)
				}),
				"aria-label": "Day"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				inputMode: "numeric",
				placeholder: "MM",
				value: value.month ?? "",
				onChange: (e) => onChange({
					...value,
					month: toInt(e.target.value)
				}),
				"aria-label": "Month"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				inputMode: "numeric",
				placeholder: "YYYY",
				value: value.year ?? "",
				onChange: (e) => onChange({
					...value,
					year: toInt(e.target.value)
				}),
				"aria-label": "Year"
			})
		]
	});
}
function toInt(raw) {
	const n = Number.parseInt(raw.replace(/\D/g, ""), 10);
	return Number.isFinite(n) ? n : null;
}
function HouseholdFields({ value, onChange, kebeles }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Kebele",
				am: AM.kebele,
				required: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: value.kebeleCode,
					onChange: (e) => {
						const kebele = kebeles.find((k) => k.code === e.target.value);
						onChange({
							...value,
							kebeleCode: e.target.value,
							kebeleName: kebele?.name ?? value.kebeleName
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select kebele"
					}), kebeles.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: k.code,
						children: [
							k.code,
							" · ",
							k.name
						]
					}, k.code))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Gote",
					am: AM.gote,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: value.gote,
						onChange: (e) => onChange({
							...value,
							gote: e.target.value
						}),
						placeholder: "06"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Scheme",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: value.scheme,
						onChange: (e) => onChange({
							...value,
							scheme: e.target.value
						}),
						children: SCHEMES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.value,
							children: s.label
						}, s.value))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Sliding scale",
					am: AM.sliding,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: value.slidingScale,
						onChange: (e) => onChange({
							...value,
							slidingScale: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Select"
						}), SLIDING_SCALES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Rural / Town",
					am: AM.settlement,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: value.settlement,
						onChange: (e) => onChange({
							...value,
							settlement: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Select"
						}), SETTLEMENTS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Enrollment date",
				am: AM.enrollment,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateFields, {
					value: value.enroll,
					onChange: (enroll) => onChange({
						...value,
						enroll
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-3 rounded-[12px] border border-border bg-surface px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: value.hasCard,
					onChange: (e) => onChange({
						...value,
						hasCard: e.target.checked
					}),
					className: "size-4 accent-primary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm",
					children: ["Has CBHI ID card ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: AM.hasCard
					})]
				})]
			})
		]
	});
}
var emptyHousehold = () => ({
	scheme: "P",
	kebeleName: "",
	kebeleCode: "",
	gote: "",
	slidingScale: "Middle",
	settlement: "Rural",
	hasCard: true,
	enroll: {
		day: null,
		month: null,
		year: null
	}
});
function MemberFields({ value, onChange, lockHead }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Full name",
				am: AM.fullName,
				required: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: value.name,
					onChange: (e) => onChange({
						...value,
						name: e.target.value
					}),
					placeholder: "e.g. Fadumo Farax Abdi",
					autoComplete: "name"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Gender",
				am: AM.gender,
				required: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: value.gender,
					onChange: (e) => onChange({
						...value,
						gender: e.target.value
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select"
					}), GENDERS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: g,
						children: g
					}, g))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Date of birth",
				am: AM.dob,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateFields, {
					value: value.dob,
					onChange: (dob) => onChange({
						...value,
						dob
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Relationship",
				am: AM.relationship,
				required: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: value.relationship,
					disabled: lockHead,
					onChange: (e) => onChange({
						...value,
						relationship: e.target.value
					}),
					children: RELATIONSHIPS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: r,
						children: r
					}, r))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Profession",
				am: AM.profession,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: value.profession,
					onChange: (e) => onChange({
						...value,
						profession: e.target.value
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select"
					}), PROFESSIONS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p,
						children: p
					}, p))]
				})
			})
		]
	});
}
var emptyMember = (relationship = "Household Head") => ({
	name: "",
	gender: "",
	dob: {
		day: null,
		month: null,
		year: null
	},
	relationship,
	profession: ""
});
//#endregion
export { emptyMember as i, MemberFields as n, emptyHousehold as r, HouseholdFields as t };
