import { Input } from "@/components/ui/input";
import type { PartialDate } from "@/lib/cbhi/types";

export function DateFields({
  value,
  onChange,
}: {
  value: PartialDate;
  onChange: (next: PartialDate) => void;
}) {
  return (
    <div className="grid grid-cols-3 gap-2">
      <Input
        inputMode="numeric"
        placeholder="DD"
        value={value.day ?? ""}
        onChange={(e) => onChange({ ...value, day: toInt(e.target.value) })}
        aria-label="Day"
      />
      <Input
        inputMode="numeric"
        placeholder="MM"
        value={value.month ?? ""}
        onChange={(e) => onChange({ ...value, month: toInt(e.target.value) })}
        aria-label="Month"
      />
      <Input
        inputMode="numeric"
        placeholder="YYYY"
        value={value.year ?? ""}
        onChange={(e) => onChange({ ...value, year: toInt(e.target.value) })}
        aria-label="Year"
      />
    </div>
  );
}

function toInt(raw: string): number | null {
  const n = Number.parseInt(raw.replace(/\D/g, ""), 10);
  return Number.isFinite(n) ? n : null;
}
