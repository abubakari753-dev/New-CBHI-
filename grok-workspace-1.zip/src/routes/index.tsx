import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader, StatCard } from "@/components/page-header";
import { useDbReady, useSettings, useStats, bumpRegistry } from "@/hooks/use-registry";
import { formatNumber } from "@/lib/cbhi/format";
import { importSeed, loadSeedGzip } from "@/lib/cbhi/seed";

export const Route = createFileRoute("/")({ component: HomePage });

function HomePage() {
  const { ready, error } = useDbReady();
  const stats = useStats();
  const settings = useSettings();
  const [seeding, setSeeding] = useState(false);
  const [progress, setProgress] = useState("");

  if (!ready) {
    return <p className="py-16 text-center text-sm text-muted">{error ?? "Opening local registry…"}</p>;
  }

  const loadSeed = async () => {
    setSeeding(true);
    try {
      const seed = await loadSeedGzip();
      const result = await importSeed(seed, (done, total) => {
        setProgress(`${done.toLocaleString()} / ${total.toLocaleString()} households`);
      });
      bumpRegistry();
      toast.success(`Loaded ${result.households.toLocaleString()} households`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not load seed data");
    } finally {
      setSeeding(false);
      setProgress("");
    }
  };

  const empty = (stats?.households ?? 0) === 0;

  return (
    <div>
      <PageHeader
        title={settings ? settings.woreda : "CBHI Registry"}
        subtitle={
          settings
            ? `${settings.region} · ${settings.zone} · codes ${settings.regionCode}/${settings.zoneCode}/${settings.woredaCode}`
            : "Community-Based Health Insurance"
        }
        action={
          <Button asChild>
            <Link to="/households/new">Register</Link>
          </Button>
        }
      />

      {empty ? (
        <EmptyState
          title="No households on this device yet"
          body="Register families in the field, or load the 2017 Shinile woreda database (6,859 households, 25,261 members) into the local store."
          action={
            <div className="flex flex-col items-center gap-2">
              <Button onClick={loadSeed} disabled={seeding}>
                {seeding ? "Loading…" : "Load 2017 Shinile database"}
              </Button>
              {progress ? <p className="text-xs text-muted">{progress}</p> : null}
              <Button variant="ghost" asChild>
                <Link to="/households/new">Start with a new household</Link>
              </Button>
            </div>
          }
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard label="Households" value={formatNumber(stats?.households ?? 0)} />
            <StatCard label="Members" value={formatNumber(stats?.members ?? 0)} />
            <StatCard label="Kebeles" value={formatNumber(stats?.kebeles ?? 0)} />
            <StatCard label="With ID card" value={formatNumber(stats?.withCard ?? 0)} />
          </div>

          <section className="mt-6 rounded-[24px] border border-border bg-surface p-5 shadow-card">
            <h2 className="text-sm font-semibold">Sliding scale</h2>
            <div className="mt-4 grid gap-3">
              {["Higher", "Middle", "Lower"].map((key) => {
                const count = stats?.byScale[key] ?? 0;
                const total = stats?.households || 1;
                const pct = Math.round((count / total) * 100);
                return (
                  <div key={key}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span>{key}</span>
                      <span className="tabular text-muted">
                        {formatNumber(count)} · {pct}%
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-bg">
                      <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="mt-6 rounded-[24px] border border-border bg-surface p-5 shadow-card">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold">Kebeles</h2>
              <Link to="/settings" className="text-sm font-medium text-primary">
                Manage
              </Link>
            </div>
            <ul className="mt-3 divide-y divide-border">
              {(stats?.byKebele ?? []).slice(0, 8).map((k) => (
                <li key={k.code}>
                  <Link
                    to="/households"
                    search={{ kebele: k.code }}
                    className="flex min-h-12 items-center justify-between py-2"
                  >
                    <span>
                      <span className="font-medium">{k.name}</span>
                      <span className="ml-2 text-xs text-muted">{k.code}</span>
                    </span>
                    <span className="tabular text-sm text-muted">{formatNumber(k.count)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </>
      )}
    </div>
  );
}
