import { db, ensureDb, getSettings, nextBeneficiaryId, refreshHouseholdDerived, toHouseholdRecord, toMemberRecord } from "./db";
import { buildHouseholdCode, codeToId, memberKey, nextSeq, padBeneficiary } from "./ids";
import type {
  HouseholdFilters,
  HouseholdInput,
  HouseholdRecord,
  KebeleRecord,
  MemberInput,
  MemberRecord,
  RegistryStats,
} from "./types";

export async function getStats(): Promise<RegistryStats> {
  await ensureDb();
  const [households, members, kebeles] = await Promise.all([
    db.households.toArray(),
    db.members.count(),
    db.kebeles.toArray(),
  ]);
  const byScale: Record<string, number> = { Higher: 0, Middle: 0, Lower: 0 };
  const bySettlement: Record<string, number> = { Rural: 0, Town: 0 };
  const kebeleCounts = new Map<string, number>();
  let withCard = 0;
  for (const hh of households) {
    if (hh.slidingScale) byScale[hh.slidingScale] = (byScale[hh.slidingScale] ?? 0) + 1;
    if (hh.settlement) bySettlement[hh.settlement] = (bySettlement[hh.settlement] ?? 0) + 1;
    if (hh.hasCard) withCard += 1;
    kebeleCounts.set(hh.kebeleCode, (kebeleCounts.get(hh.kebeleCode) ?? 0) + 1);
  }
  const byKebele = kebeles
    .map((k) => ({ code: k.code, name: k.name, count: kebeleCounts.get(k.code) ?? 0 }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  return {
    households: households.length,
    members,
    kebeles: kebeles.length,
    withCard,
    byScale,
    bySettlement,
    byKebele,
  };
}

export async function listKebeles(): Promise<KebeleRecord[]> {
  await ensureDb();
  const rows = await db.kebeles.toArray();
  return rows.sort((a, b) => a.code.localeCompare(b.code));
}

export async function upsertKebele(kebele: KebeleRecord): Promise<void> {
  await db.kebeles.put({ code: kebele.code.padStart(2, "0"), name: kebele.name.trim() });
}

export async function deleteKebele(code: string): Promise<void> {
  const used = await db.households.where("kebeleCode").equals(code).count();
  if (used > 0) {
    throw new Error(`Cannot delete kebele ${code}: ${used} household(s) still use it.`);
  }
  await db.kebeles.delete(code);
}

function matchesFilters(hh: HouseholdRecord, filters: HouseholdFilters): boolean {
  if (filters.kebeleCode && hh.kebeleCode !== filters.kebeleCode) return false;
  if (filters.slidingScale !== "all" && hh.slidingScale !== filters.slidingScale) return false;
  if (filters.settlement !== "all" && hh.settlement !== filters.settlement) return false;
  if (filters.scheme !== "all" && hh.scheme !== filters.scheme) return false;
  if (filters.q) {
    const q = filters.q.toLowerCase().trim();
    if (!hh.search.includes(q) && !hh.code.toLowerCase().includes(q)) return false;
  }
  return true;
}

export async function listHouseholds(filters: HouseholdFilters): Promise<HouseholdRecord[]> {
  await ensureDb();
  let rows: HouseholdRecord[];
  if (filters.kebeleCode) {
    rows = await db.households.where("kebeleCode").equals(filters.kebeleCode).toArray();
  } else {
    rows = await db.households.toArray();
  }
  const filtered = rows.filter((hh) => matchesFilters(hh, filters));
  filtered.sort((a, b) => a.code.localeCompare(b.code));
  return filtered;
}

export async function getHousehold(id: string): Promise<HouseholdRecord | undefined> {
  await ensureDb();
  return db.households.get(id);
}

export async function getHouseholdMembers(householdId: string): Promise<MemberRecord[]> {
  const rows = await db.members.where("householdId").equals(householdId).toArray();
  rows.sort((a, b) => a.beneficiaryId.localeCompare(b.beneficiaryId));
  return rows;
}

export async function searchMembers(q: string, limit = 200): Promise<MemberRecord[]> {
  await ensureDb();
  const query = q.toLowerCase().trim();
  const rows = await db.members.toArray();
  const filtered = query
    ? rows.filter((m) => m.search.includes(query) || m.name.toLowerCase().includes(query))
    : rows;
  filtered.sort((a, b) => a.name.localeCompare(b.name));
  return filtered.slice(0, limit);
}

export async function createHousehold(input: HouseholdInput, head: MemberInput): Promise<HouseholdRecord> {
  await ensureDb();
  const settings = await getSettings();
  const existing = await db.households.where("kebeleCode").equals(input.kebeleCode).toArray();
  const codes = existing.filter((h) => h.scheme === input.scheme).map((h) => h.code);
  const prefix = `${input.scheme}/${settings.regionCode}/${settings.zoneCode}/${settings.woredaCode}/${input.kebeleCode}/`;
  const seq = nextSeq(codes, prefix);
  const code = buildHouseholdCode({
    scheme: input.scheme,
    regionCode: settings.regionCode,
    zoneCode: settings.zoneCode,
    woredaCode: settings.woredaCode,
    kebeleCode: input.kebeleCode,
    seq,
  });
  const id = codeToId(code);
  if (await db.households.get(id)) {
    throw new Error(`Household ${code} already exists.`);
  }
  const headMember = toMemberRecord(id, code, {
    ...head,
    relationship: "Household Head",
    beneficiaryId: "00",
  });
  const hh = toHouseholdRecord(code, input, headMember.name, 1, [headMember.name]);
  await db.transaction("rw", db.households, db.members, async () => {
    await db.households.add(hh);
    await db.members.add(headMember);
  });
  return hh;
}

export async function updateHousehold(id: string, input: HouseholdInput): Promise<void> {
  const hh = await db.households.get(id);
  if (!hh) throw new Error("Household not found.");
  hh.scheme = input.scheme;
  hh.kebeleName = input.kebeleName;
  hh.kebeleCode = input.kebeleCode;
  hh.gote = input.gote.trim();
  hh.slidingScale = input.slidingScale;
  hh.settlement = input.settlement;
  hh.hasCard = input.hasCard;
  hh.enrollDay = input.enroll.day;
  hh.enrollMonth = input.enroll.month;
  hh.enrollYear = input.enroll.year;
  hh.updatedAt = Date.now();
  await db.households.put(hh);
  await refreshHouseholdDerived(id);
}

export async function deleteHousehold(id: string): Promise<void> {
  await db.transaction("rw", db.households, db.members, async () => {
    await db.members.where("householdId").equals(id).delete();
    await db.households.delete(id);
  });
}

export async function addMember(householdId: string, input: MemberInput): Promise<MemberRecord> {
  const hh = await db.households.get(householdId);
  if (!hh) throw new Error("Household not found.");
  const beneficiaryId = padBeneficiary(input.beneficiaryId ?? (await nextBeneficiaryId(householdId)));
  const rec = toMemberRecord(householdId, hh.code, { ...input, beneficiaryId });
  if (await db.members.get(rec.id)) {
    throw new Error(`Beneficiary ${beneficiaryId} already exists in this household.`);
  }
  await db.members.add(rec);
  await refreshHouseholdDerived(householdId);
  return rec;
}

export async function updateMember(memberId: string, input: MemberInput): Promise<void> {
  const existing = await db.members.get(memberId);
  if (!existing) throw new Error("Member not found.");
  const nextId = memberKey(existing.householdId, padBeneficiary(input.beneficiaryId ?? existing.beneficiaryId));
  const rec = toMemberRecord(existing.householdId, existing.householdCode, {
    ...input,
    beneficiaryId: padBeneficiary(input.beneficiaryId ?? existing.beneficiaryId),
  });
  rec.id = nextId;
  await db.transaction("rw", db.members, db.households, async () => {
    if (nextId !== memberId) {
      if (await db.members.get(nextId)) {
        throw new Error("That beneficiary number is already used.");
      }
      await db.members.delete(memberId);
    }
    await db.members.put(rec);
  });
  await refreshHouseholdDerived(existing.householdId);
}

export async function deleteMember(memberId: string): Promise<void> {
  const existing = await db.members.get(memberId);
  if (!existing) return;
  if (existing.beneficiaryId === "00" || existing.relationship === "Household Head") {
    const count = await db.members.where("householdId").equals(existing.householdId).count();
    if (count <= 1) {
      throw new Error("Cannot delete the only household head. Delete the household instead.");
    }
  }
  await db.members.delete(memberId);
  await refreshHouseholdDerived(existing.householdId);
}

export async function clearRegistry(): Promise<void> {
  await db.transaction("rw", db.households, db.members, async () => {
    await db.households.clear();
    await db.members.clear();
  });
}
