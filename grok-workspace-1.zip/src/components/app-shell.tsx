import { Link, useRouterState } from "@tanstack/react-router";
import { Database, Home, Plus, Users, Warehouse } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/households", label: "Households", icon: Warehouse },
  { to: "/households/new", label: "Register", icon: Plus },
  { to: "/members", label: "Members", icon: Users },
  { to: "/data", label: "Data", icon: Database },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (import.meta.env.DEV) return;
    if (!("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  }, []);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-30 border-b border-border bg-bg-elevated/95 backdrop-blur-sm">
        <div className="app-safe mx-auto flex h-14 max-w-5xl items-center justify-between">
          <Link to="/" className="flex items-baseline gap-2">
            <span className="text-[15px] font-semibold tracking-tight">CBHI Registry</span>
            <span className="hidden text-xs text-muted sm:inline">የጤና መድን መዝገብ</span>
          </Link>
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-primary-soft px-2.5 py-1 text-[11px] font-medium text-primary">
              Offline
            </span>
            <Link to="/settings" className="text-sm font-medium text-muted hover:text-fg">
              Settings
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl pb-24 pt-4 app-safe">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm">
        <ul className="mx-auto grid max-w-5xl grid-cols-5">
          {NAV.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : item.to === "/households"
                  ? pathname === "/households" || (pathname.startsWith("/households/") && pathname !== "/households/new")
                  : pathname === item.to || pathname.startsWith(`${item.to}/`);
            const Icon = item.icon;
            const isRegister = item.to === "/households/new";
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                    active ? "text-primary" : "text-muted",
                  )}
                >
                  <span
                    className={cn(
                      "flex size-9 items-center justify-center rounded-full",
                      isRegister && "bg-primary text-primary-fg",
                      !isRegister && active && "bg-primary-soft",
                    )}
                  >
                    <Icon className="size-4" strokeWidth={2} />
                  </span>
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
