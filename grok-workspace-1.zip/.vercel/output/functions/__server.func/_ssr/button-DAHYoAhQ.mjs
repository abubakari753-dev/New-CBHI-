import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { s as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as cn } from "./router-b6X6bWYl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-DAHYoAhQ.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-opacity duration-150 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] select-none", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-primary-soft text-primary hover:opacity-90",
			outline: "border border-border bg-surface text-fg hover:bg-bg-elevated",
			ghost: "text-fg hover:bg-fg/5",
			danger: "bg-danger text-white hover:opacity-90"
		},
		size: {
			sm: "h-9 rounded-[8px] px-3 text-sm",
			md: "h-11 rounded-[12px] px-4 text-sm",
			lg: "h-12 rounded-[14px] px-5 text-base",
			icon: "size-11 rounded-[12px]"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { Button as t };
