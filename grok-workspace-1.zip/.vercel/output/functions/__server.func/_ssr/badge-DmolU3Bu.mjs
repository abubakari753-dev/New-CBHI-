import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as cn } from "./router-b6X6bWYl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-DmolU3Bu.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ children, tone = "neutral", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", {
			neutral: "bg-bg text-fg",
			primary: "bg-primary-soft text-primary",
			warn: "bg-warning-soft text-warning",
			danger: "bg-danger-soft text-danger",
			muted: "bg-bg text-muted"
		}[tone], className),
		children
	});
}
//#endregion
export { Badge as t };
