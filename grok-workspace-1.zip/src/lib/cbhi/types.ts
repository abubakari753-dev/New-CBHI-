export type Scheme = "P" | "I";
export type Gender = "Male" | "Female" | "";
export type SlidingScale = "Higher" | "Middle" | "Lower" | "";
export type Settlement = "Rural" | "Town" | "";

export type PartialDate = {
  day: number | null;
  month: number | null;
  year: number | null;
};

export type HouseholdRecord = {
  id: string;
  code: string;
  scheme: Scheme;
  kebeleName: string;
  kebeleCode: string;
  gote: string;
  slidingScale: SlidingScale;
  settlement: Settlement;
  hasCard: boolean;
  enrollDay: number | null;
  enrollMonth: number | null;
  enrollYear: number | null;
  headName: string;
  memberCount: number;
  search: string;
  updatedAt: number;
};

export type MemberRecord = {
  id: string;
  householdId: string;
  householdCode: string;
  beneficiaryId: string;
  name: string;
  gender: Gender;
  dobDay: number | null;
  dobMonth: number | null;
  dobYear: number | null;
  relationship: string;
  profession: string;
  search: string;
};

export type KebeleRecord = {
  code: string;
  name: string;
};

export type RegistrySettings = {
  region: string;
  zone: string;
  woreda: string;
  regionCode: string;
  zoneCode: string;
  woredaCode: string;
};

export type HouseholdInput = {
  scheme: Scheme;
  kebeleName: string;
  kebeleCode: string;
  gote: string;
  slidingScale: SlidingScale;
  settlement: Settlement;
  hasCard: boolean;
  enroll: PartialDate;
};

export type MemberInput = {
  name: string;
  gender: Gender;
  dob: PartialDate;
  relationship: string;
  profession: string;
  beneficiaryId?: string;
};

export type HouseholdFilters = {
  q: string;
  kebeleCode: string;
  slidingScale: SlidingScale | "all";
  settlement: Settlement | "all";
  scheme: Scheme | "all";
};

export type RegistryStats = {
  households: number;
  members: number;
  kebeles: number;
  withCard: number;
  byScale: Record<string, number>;
  bySettlement: Record<string, number>;
  byKebele: { code: string; name: string; count: number }[];
};

export const DEFAULT_SETTINGS: RegistrySettings = {
  region: "Somali",
  zone: "Sitti",
  woreda: "Shinile",
  regionCode: "05",
  zoneCode: "04",
  woredaCode: "09",
};

export const SHINILE_KEBELES: KebeleRecord[] = [
  { code: "01", name: "Shinile 01" },
  { code: "02", name: "Shinile 02" },
  { code: "03", name: "Toome" },
  { code: "04", name: "Marmaarsa" },
  { code: "05", name: "Dinlay" },
  { code: "06", name: "Jeedane" },
  { code: "07", name: "Lasdheere" },
  { code: "08", name: "Dhagaxjabis" },
  { code: "09", name: "Kalabaydh" },
  { code: "10", name: "Baraaq" },
  { code: "11", name: "Gaad" },
  { code: "12", name: "Harawe" },
  { code: "13", name: "Miile" },
  { code: "14", name: "Cayiliso" },
  { code: "15", name: "Bisle" },
  { code: "16", name: "Xaaray" },
  { code: "17", name: "Xadhkalay" },
  { code: "18", name: "Meete" },
  { code: "19", name: "Fandhale" },
];
