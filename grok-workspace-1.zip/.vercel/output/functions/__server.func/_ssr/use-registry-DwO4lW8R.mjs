import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Dexie } from "../_libs/dexie.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-registry-DwO4lW8R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ title, subtitle, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 flex items-start justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: title
		}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: subtitle
		}) : null] }), action]
	});
}
function EmptyState({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[24px] border border-dashed border-border bg-surface px-5 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-sm text-muted",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: action
			}) : null
		]
	});
}
function StatCard({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[20px] border border-border bg-surface p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-wide text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-2xl font-semibold tabular tracking-tight",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function scaleTone(scale) {
	if (scale === "Higher") return "primary";
	if (scale === "Lower") return "warn";
	if (scale === "Middle") return "neutral";
	return "muted";
}
var DEFAULT_SETTINGS = {
	region: "Somali",
	zone: "Sitti",
	woreda: "Shinile",
	regionCode: "05",
	zoneCode: "04",
	woredaCode: "09"
};
var SHINILE_KEBELES = [
	{
		code: "01",
		name: "Shinile 01"
	},
	{
		code: "02",
		name: "Shinile 02"
	},
	{
		code: "03",
		name: "Toome"
	},
	{
		code: "04",
		name: "Marmaarsa"
	},
	{
		code: "05",
		name: "Dinlay"
	},
	{
		code: "06",
		name: "Jeedane"
	},
	{
		code: "07",
		name: "Lasdheere"
	},
	{
		code: "08",
		name: "Dhagaxjabis"
	},
	{
		code: "09",
		name: "Kalabaydh"
	},
	{
		code: "10",
		name: "Baraaq"
	},
	{
		code: "11",
		name: "Gaad"
	},
	{
		code: "12",
		name: "Harawe"
	},
	{
		code: "13",
		name: "Miile"
	},
	{
		code: "14",
		name: "Cayiliso"
	},
	{
		code: "15",
		name: "Bisle"
	},
	{
		code: "16",
		name: "Xaaray"
	},
	{
		code: "17",
		name: "Xadhkalay"
	},
	{
		code: "18",
		name: "Meete"
	},
	{
		code: "19",
		name: "Fandhale"
	}
];
function codeToId(code) {
	return code.trim().toUpperCase().replaceAll("/", "-");
}
function memberKey(householdId, beneficiaryId) {
	return `${householdId}:${padBeneficiary(beneficiaryId)}`;
}
function memberDisplayCode(householdCode, beneficiaryId) {
	return `${householdCode.toUpperCase()}-${padBeneficiary(beneficiaryId)}`;
}
function padBeneficiary(value) {
	const n = String(value ?? "").replace(/\D/g, "");
	if (!n) return "00";
	return n.padStart(2, "0");
}
function padKebele(value) {
	const n = String(value ?? "").replace(/\D/g, "");
	if (!n) return "01";
	return n.padStart(2, "0");
}
function padSeq(n) {
	if (n < 0) n = 0;
	if (n > 9999) return String(n).padStart(5, "0");
	return String(n).padStart(4, "0");
}
function buildHouseholdCode(opts) {
	return `${opts.scheme === "I" ? "I" : "P"}/${String(opts.regionCode).replace(/\D/g, "").padStart(2, "0") || "00"}/${String(opts.zoneCode).replace(/\D/g, "").padStart(2, "0") || "00"}/${String(opts.woredaCode).replace(/\D/g, "").padStart(2, "0") || "00"}/${padKebele(opts.kebeleCode)}/${padSeq(opts.seq)}`;
}
function nextSeq(codes, prefix) {
	const needle = prefix.toUpperCase();
	let max = 0;
	for (const code of codes) {
		const value = code.toUpperCase();
		if (!value.startsWith(needle)) continue;
		const tail = value.slice(needle.length);
		const n = Number.parseInt(tail, 10);
		if (Number.isFinite(n) && n > max) max = n;
	}
	return max + 1;
}
function searchBlob(...parts) {
	return parts.filter(Boolean).join(" ").toLowerCase().replaceAll("/", " ").replaceAll("-", " ").replace(/\s+/g, " ").trim();
}
var CbhiDatabase = class extends Dexie {
	households;
	members;
	kebeles;
	meta;
	constructor() {
		super("cbhi-registry-v1");
		this.version(1).stores({
			households: "id, code, kebeleCode, kebeleName, slidingScale, settlement, scheme, headName, updatedAt",
			members: "id, householdId, householdCode, beneficiaryId, name, gender, relationship",
			kebeles: "code, name",
			meta: "key"
		});
	}
};
var db = new CbhiDatabase();
async function ensureDb() {
	await db.open();
	if (!await db.meta.get("settings")) await db.meta.put({
		key: "settings",
		value: DEFAULT_SETTINGS
	});
	if (await db.kebeles.count() === 0) await db.kebeles.bulkPut(SHINILE_KEBELES);
}
async function getSettings() {
	const row = await db.meta.get("settings");
	return {
		...DEFAULT_SETTINGS,
		...row?.value ?? {}
	};
}
async function saveSettings(next) {
	await db.meta.put({
		key: "settings",
		value: next
	});
}
function buildHouseholdSearch(hh, memberNames) {
	return searchBlob(hh.code, hh.kebeleName, hh.kebeleCode, hh.gote, hh.headName, ...memberNames);
}
function toMemberRecord(householdId, householdCode, input) {
	const beneficiaryId = padBeneficiary(input.beneficiaryId ?? "00");
	const name = input.name.trim();
	return {
		id: memberKey(householdId, beneficiaryId),
		householdId,
		householdCode,
		beneficiaryId,
		name,
		gender: input.gender,
		dobDay: input.dob.day,
		dobMonth: input.dob.month,
		dobYear: input.dob.year,
		relationship: input.relationship,
		profession: input.profession,
		search: searchBlob(name, householdCode, beneficiaryId, input.relationship, input.profession)
	};
}
function toHouseholdRecord(code, input, headName, memberCount, memberNames) {
	const rec = {
		id: codeToId(code),
		code: code.toUpperCase(),
		scheme: input.scheme,
		kebeleName: input.kebeleName,
		kebeleCode: input.kebeleCode,
		gote: input.gote.trim(),
		slidingScale: input.slidingScale,
		settlement: input.settlement,
		hasCard: input.hasCard,
		enrollDay: input.enroll.day,
		enrollMonth: input.enroll.month,
		enrollYear: input.enroll.year,
		headName,
		memberCount,
		search: "",
		updatedAt: Date.now()
	};
	rec.search = buildHouseholdSearch(rec, memberNames);
	return rec;
}
async function refreshHouseholdDerived(householdId) {
	const hh = await db.households.get(householdId);
	if (!hh) return;
	const members = await db.members.where("householdId").equals(householdId).toArray();
	members.sort((a, b) => a.beneficiaryId.localeCompare(b.beneficiaryId));
	hh.headName = (members.find((m) => m.relationship === "Household Head") ?? members[0])?.name ?? "";
	hh.memberCount = members.length;
	hh.search = buildHouseholdSearch(hh, members.map((m) => m.name));
	hh.updatedAt = Date.now();
	await db.households.put(hh);
}
async function nextBeneficiaryId(householdId) {
	const members = await db.members.where("householdId").equals(householdId).toArray();
	let max = -1;
	for (const m of members) {
		const n = Number.parseInt(m.beneficiaryId, 10);
		if (Number.isFinite(n) && n > max) max = n;
	}
	return padBeneficiary(max + 1);
}
async function getStats() {
	await ensureDb();
	const [households, members, kebeles] = await Promise.all([
		db.households.toArray(),
		db.members.count(),
		db.kebeles.toArray()
	]);
	const byScale = {
		Higher: 0,
		Middle: 0,
		Lower: 0
	};
	const bySettlement = {
		Rural: 0,
		Town: 0
	};
	const kebeleCounts = /* @__PURE__ */ new Map();
	let withCard = 0;
	for (const hh of households) {
		if (hh.slidingScale) byScale[hh.slidingScale] = (byScale[hh.slidingScale] ?? 0) + 1;
		if (hh.settlement) bySettlement[hh.settlement] = (bySettlement[hh.settlement] ?? 0) + 1;
		if (hh.hasCard) withCard += 1;
		kebeleCounts.set(hh.kebeleCode, (kebeleCounts.get(hh.kebeleCode) ?? 0) + 1);
	}
	const byKebele = kebeles.map((k) => ({
		code: k.code,
		name: k.name,
		count: kebeleCounts.get(k.code) ?? 0
	})).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
	return {
		households: households.length,
		members,
		kebeles: kebeles.length,
		withCard,
		byScale,
		bySettlement,
		byKebele
	};
}
async function listKebeles() {
	await ensureDb();
	return (await db.kebeles.toArray()).sort((a, b) => a.code.localeCompare(b.code));
}
async function upsertKebele(kebele) {
	await db.kebeles.put({
		code: kebele.code.padStart(2, "0"),
		name: kebele.name.trim()
	});
}
async function deleteKebele(code) {
	const used = await db.households.where("kebeleCode").equals(code).count();
	if (used > 0) throw new Error(`Cannot delete kebele ${code}: ${used} household(s) still use it.`);
	await db.kebeles.delete(code);
}
function matchesFilters(hh, filters) {
	if (filters.kebeleCode && hh.kebeleCode !== filters.kebeleCode) return false;
	if (filters.slidingScale !== "all" && hh.slidingScale !== filters.slidingScale) return false;
	if (filters.settlement !== "all" && hh.settlement !== filters.settlement) return false;
	if (filters.scheme !== "all" && hh.scheme !== filters.scheme) return false;
	if (filters.q) {
		const q = filters.q.toLowerCase().trim();
		if (!hh.search.includes(q) && !hh.code.toLowerCase().includes(q)) return false;
	}
	return true;
}
async function listHouseholds(filters) {
	await ensureDb();
	let rows;
	if (filters.kebeleCode) rows = await db.households.where("kebeleCode").equals(filters.kebeleCode).toArray();
	else rows = await db.households.toArray();
	const filtered = rows.filter((hh) => matchesFilters(hh, filters));
	filtered.sort((a, b) => a.code.localeCompare(b.code));
	return filtered;
}
async function getHousehold(id) {
	await ensureDb();
	return db.households.get(id);
}
async function getHouseholdMembers(householdId) {
	const rows = await db.members.where("householdId").equals(householdId).toArray();
	rows.sort((a, b) => a.beneficiaryId.localeCompare(b.beneficiaryId));
	return rows;
}
async function searchMembers(q, limit = 200) {
	await ensureDb();
	const query = q.toLowerCase().trim();
	const rows = await db.members.toArray();
	const filtered = query ? rows.filter((m) => m.search.includes(query) || m.name.toLowerCase().includes(query)) : rows;
	filtered.sort((a, b) => a.name.localeCompare(b.name));
	return filtered.slice(0, limit);
}
async function createHousehold(input, head) {
	await ensureDb();
	const settings = await getSettings();
	const seq = nextSeq((await db.households.where("kebeleCode").equals(input.kebeleCode).toArray()).filter((h) => h.scheme === input.scheme).map((h) => h.code), `${input.scheme}/${settings.regionCode}/${settings.zoneCode}/${settings.woredaCode}/${input.kebeleCode}/`);
	const code = buildHouseholdCode({
		scheme: input.scheme,
		regionCode: settings.regionCode,
		zoneCode: settings.zoneCode,
		woredaCode: settings.woredaCode,
		kebeleCode: input.kebeleCode,
		seq
	});
	const id = codeToId(code);
	if (await db.households.get(id)) throw new Error(`Household ${code} already exists.`);
	const headMember = toMemberRecord(id, code, {
		...head,
		relationship: "Household Head",
		beneficiaryId: "00"
	});
	const hh = toHouseholdRecord(code, input, headMember.name, 1, [headMember.name]);
	await db.transaction("rw", db.households, db.members, async () => {
		await db.households.add(hh);
		await db.members.add(headMember);
	});
	return hh;
}
async function updateHousehold(id, input) {
	const hh = await db.households.get(id);
	if (!hh) throw new Error("Household not found.");
	hh.scheme = input.scheme;
	hh.kebeleName = input.kebeleName;
	hh.kebeleCode = input.kebeleCode;
	hh.gote = input.gote.trim();
	hh.slidingScale = input.slidingScale;
	hh.settlement = input.settlement;
	hh.hasCard = input.hasCard;
	hh.enrollDay = input.enroll.day;
	hh.enrollMonth = input.enroll.month;
	hh.enrollYear = input.enroll.year;
	hh.updatedAt = Date.now();
	await db.households.put(hh);
	await refreshHouseholdDerived(id);
}
async function deleteHousehold(id) {
	await db.transaction("rw", db.households, db.members, async () => {
		await db.members.where("householdId").equals(id).delete();
		await db.households.delete(id);
	});
}
async function addMember(householdId, input) {
	const hh = await db.households.get(householdId);
	if (!hh) throw new Error("Household not found.");
	const beneficiaryId = padBeneficiary(input.beneficiaryId ?? await nextBeneficiaryId(householdId));
	const rec = toMemberRecord(householdId, hh.code, {
		...input,
		beneficiaryId
	});
	if (await db.members.get(rec.id)) throw new Error(`Beneficiary ${beneficiaryId} already exists in this household.`);
	await db.members.add(rec);
	await refreshHouseholdDerived(householdId);
	return rec;
}
async function updateMember(memberId, input) {
	const existing = await db.members.get(memberId);
	if (!existing) throw new Error("Member not found.");
	const nextId = memberKey(existing.householdId, padBeneficiary(input.beneficiaryId ?? existing.beneficiaryId));
	const rec = toMemberRecord(existing.householdId, existing.householdCode, {
		...input,
		beneficiaryId: padBeneficiary(input.beneficiaryId ?? existing.beneficiaryId)
	});
	rec.id = nextId;
	await db.transaction("rw", db.members, db.households, async () => {
		if (nextId !== memberId) {
			if (await db.members.get(nextId)) throw new Error("That beneficiary number is already used.");
			await db.members.delete(memberId);
		}
		await db.members.put(rec);
	});
	await refreshHouseholdDerived(existing.householdId);
}
async function deleteMember(memberId) {
	const existing = await db.members.get(memberId);
	if (!existing) return;
	if (existing.beneficiaryId === "00" || existing.relationship === "Household Head") {
		if (await db.members.where("householdId").equals(existing.householdId).count() <= 1) throw new Error("Cannot delete the only household head. Delete the household instead.");
	}
	await db.members.delete(memberId);
	await refreshHouseholdDerived(existing.householdId);
}
async function clearRegistry() {
	await db.transaction("rw", db.households, db.members, async () => {
		await db.households.clear();
		await db.members.clear();
	});
}
var revision = 0;
var listeners = /* @__PURE__ */ new Set();
function bumpRegistry() {
	revision += 1;
	listeners.forEach((fn) => fn());
}
function useRegistryTick() {
	const [tick, setTick] = (0, import_react.useState)(revision);
	(0, import_react.useEffect)(() => {
		const fn = () => setTick(revision);
		listeners.add(fn);
		return () => {
			listeners.delete(fn);
		};
	}, []);
	return tick;
}
function useDbReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		ensureDb().then(() => {
			if (!cancelled) setReady(true);
		}).catch((err) => {
			if (!cancelled) setError(err instanceof Error ? err.message : "Database failed to open");
		});
		return () => {
			cancelled = true;
		};
	}, []);
	return {
		ready,
		error
	};
}
function useSettings() {
	const tick = useRegistryTick();
	const [settings, setSettings] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getSettings().then(setSettings);
	}, [tick]);
	return settings;
}
function useStats() {
	const tick = useRegistryTick();
	const [stats, setStats] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getStats().then(setStats);
	}, [tick]);
	return stats;
}
function useKebeles() {
	const tick = useRegistryTick();
	const [kebeles, setKebeles] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		listKebeles().then(setKebeles);
	}, [tick]);
	return kebeles;
}
function useHouseholdList(filters) {
	const tick = useRegistryTick();
	const [rows, setRows] = (0, import_react.useState)(null);
	const reload = (0, import_react.useCallback)(() => {
		setRows(null);
		listHouseholds(filters).then(setRows);
	}, [
		filters.q,
		filters.kebeleCode,
		filters.slidingScale,
		filters.settlement,
		filters.scheme,
		tick
	]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		listHouseholds(filters).then((data) => {
			if (!cancelled) setRows(data);
		});
		return () => {
			cancelled = true;
		};
	}, [reload]);
	return {
		rows,
		reload
	};
}
//#endregion
export { useDbReady as A, scaleTone as C, updateHousehold as D, toMemberRecord as E, useStats as F, useKebeles as M, useRegistryTick as N, updateMember as O, useSettings as P, saveSettings as S, toHouseholdRecord as T, getSettings as _, StatCard as a, padBeneficiary as b, clearRegistry as c, deleteHousehold as d, deleteKebele as f, getHouseholdMembers as g, getHousehold as h, SHINILE_KEBELES as i, useHouseholdList as j, upsertKebele as k, createHousehold as l, ensureDb as m, EmptyState as n, addMember as o, deleteMember as p, PageHeader as r, bumpRegistry as s, DEFAULT_SETTINGS as t, db as u, listKebeles as v, searchMembers as w, padKebele as x, memberDisplayCode as y };
