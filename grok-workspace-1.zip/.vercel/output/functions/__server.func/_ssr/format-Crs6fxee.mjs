//#region node_modules/.nitro/vite/services/ssr/assets/format-Crs6fxee.js
function formatDate(date) {
	const day = date.day;
	const month = date.month;
	const year = date.year;
	if (!day && !month && !year) return "—";
	return `${day ? String(day).padStart(2, "0") : "??"}/${month ? String(month).padStart(2, "0") : "??"}/${year ? String(year) : "????"}`;
}
function formatNumber(n) {
	return new Intl.NumberFormat("en-US").format(n);
}
function ageFromDob(year, now = /* @__PURE__ */ new Date()) {
	if (!year || year < 1800 || year > now.getFullYear() + 1) return null;
	const age = now.getFullYear() - year;
	if (age < 0 || age > 130) return null;
	return age;
}
function parseLooseInt(value) {
	if (value === null || value === void 0 || value === "") return null;
	const n = typeof value === "number" ? value : Number.parseInt(String(value).trim(), 10);
	if (!Number.isFinite(n)) return null;
	return Math.trunc(n);
}
function yesNo(value) {
	return value ? "Yes" : "No";
}
//#endregion
export { yesNo as a, parseLooseInt as i, formatDate as n, formatNumber as r, ageFromDob as t };
