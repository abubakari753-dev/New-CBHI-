export const GENDERS = ["Male", "Female"] as const;

export const RELATIONSHIPS = [
  "Household Head",
  "Parent",
  "Husband",
  "Wife",
  "Son",
  "Daughter",
  "Other",
] as const;

export const PROFESSIONS = [
  "Farmer",
  "Pastoralist",
  "Merchant",
  "Job Seeker",
  "Housewife",
  "Stay at home Husband",
  "Daily Laborer",
  "Student",
  "Disabled",
  "Other",
] as const;

export const SLIDING_SCALES = ["Higher", "Middle", "Lower"] as const;

export const SETTLEMENTS = ["Rural", "Town"] as const;

export const SCHEMES = [
  { value: "P", label: "Paying (P)" },
  { value: "I", label: "Indigent (I)" },
] as const;

export const AM = {
  app: "የጤና መድን መዝገብ",
  fullName: "ሙሉ ስም",
  dob: "የትውልድ ቀን",
  gender: "ፆታ",
  householdId: "የማአጤመ ቁጥር",
  beneficiaryId: "የአባሉ መለያ ቁጥር",
  kebele: "ቀበሌ",
  gote: "ጎጥ",
  relationship: "የአባሉ ዝምድና",
  profession: "የስራ ዘርፍ",
  enrollment: "የአባልነት ምዝገባ ቀን",
  sliding: "የክፍያ ደረጃ",
  settlement: "ገጠር / ከተማ",
  hasCard: "የማአጤመ መታወቂያ አለው?",
  region: "ክልል",
  zone: "ዞን",
  woreda: "ወረዳ",
  day: "ቀን",
  month: "ወር",
  year: "ዓ/ም",
} as const;
