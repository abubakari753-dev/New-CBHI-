//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DfVLnOjh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/data",
			"/members",
			"/settings",
			"/households/$id",
			"/households/new",
			"/households/"
		],
		preloads: [
			"/assets/index--f6Xismx.js",
			"/assets/utils-BFmSEvC8.js",
			"/assets/react-dom-BRNPAwij.js",
			"/assets/link-BiHUnpjU.js",
			"/assets/lazyRouteComponent-B70E9pir.js",
			"/assets/useRouter-aVNGoVA_.js",
			"/assets/createLucideIcon-BNhjXhXU.js",
			"/assets/preload-helper-Czpn1I53.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index--f6Xismx.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BDHO5biB.js",
			"/assets/button-DpRFGJq4.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/format-CXwb-Oin.js",
			"/assets/seed-CpFRbiaI.js"
		]
	},
	"/data": {
		filePath: "/workspace/src/routes/data.tsx",
		children: void 0,
		preloads: [
			"/assets/data-B9sSY-Fr.js",
			"/assets/button-DpRFGJq4.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/format-CXwb-Oin.js",
			"/assets/seed-CpFRbiaI.js"
		]
	},
	"/members": {
		filePath: "/workspace/src/routes/members.tsx",
		children: void 0,
		preloads: [
			"/assets/members-DS2pZsGj.js",
			"/assets/search-DUMYVaBb.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/format-CXwb-Oin.js",
			"/assets/input-qgPpd7_X.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BwJ1f9nK.js",
			"/assets/button-DpRFGJq4.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/input-qgPpd7_X.js",
			"/assets/lookups-3lNYt7JE.js"
		]
	},
	"/households/$id": {
		filePath: "/workspace/src/routes/households/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-CjkLnHGD.js",
			"/assets/useNavigate-CniUINho.js",
			"/assets/button-DpRFGJq4.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/format-CXwb-Oin.js",
			"/assets/member-fields-BG5rru6t.js",
			"/assets/badge-BtmbB0-U.js"
		]
	},
	"/households/new": {
		filePath: "/workspace/src/routes/households/new.tsx",
		children: void 0,
		preloads: [
			"/assets/new-Dlmh21Mh.js",
			"/assets/useNavigate-CniUINho.js",
			"/assets/button-DpRFGJq4.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/member-fields-BG5rru6t.js"
		]
	},
	"/households/": {
		filePath: "/workspace/src/routes/households/index.tsx",
		children: void 0,
		preloads: [
			"/assets/households-WUFKuvhh.js",
			"/assets/search-DUMYVaBb.js",
			"/assets/use-registry-DwwuLF5W.js",
			"/assets/input-qgPpd7_X.js",
			"/assets/badge-BtmbB0-U.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
