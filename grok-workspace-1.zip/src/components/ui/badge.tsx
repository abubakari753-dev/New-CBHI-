import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "primary" | "warn" | "danger" | "muted";
  className?: string;
}) {
  const tones = {
    neutral: "bg-bg text-fg",
    primary: "bg-primary-soft text-primary",
    warn: "bg-warning-soft text-warning",
    danger: "bg-danger-soft text-danger",
    muted: "bg-bg text-muted",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
