import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { EmptyState, PageHeader } from "@/components/page-header";
import { useDbReady } from "@/hooks/use-registry";
import { ageFromDob } from "@/lib/cbhi/format";
import { memberDisplayCode } from "@/lib/cbhi/ids";
import { searchMembers } from "@/lib/cbhi/queries";
import type { MemberRecord } from "@/lib/cbhi/types";

export const Route = createFileRoute("/members")({
  component: MembersPage,
});

function MembersPage() {
  const { ready } = useDbReady();
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<MemberRecord[] | null>(null);

  useEffect(() => {
    if (!ready) return;
    const handle = setTimeout(() => {
      searchMembers(q, 250).then(setRows);
    }, 150);
    return () => clearTimeout(handle);
  }, [q, ready]);

  if (!ready) return <p className="py-16 text-center text-sm text-muted">Opening registry…</p>;

  return (
    <div>
      <PageHeader title="Members" subtitle="Search beneficiaries across every household" />
      <div className="relative mb-4">
        <Search className="pointer-events-none absolute top-3.5 left-3 size-4 text-subtle" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Name, ID, relationship" className="pl-9" />
      </div>
      {!rows ? (
        <p className="py-10 text-center text-sm text-muted">Searching…</p>
      ) : rows.length === 0 ? (
        <EmptyState title="No members found" body="Register a household first, or load the 2017 Shinile database from Home." />
      ) : (
        <ul className="overflow-hidden rounded-[20px] border border-border bg-surface">
          {rows.map((m) => {
            const age = ageFromDob(m.dobYear);
            return (
              <li key={m.id} className="border-b border-border last:border-b-0">
                <Link
                  to="/households/$id"
                  params={{ id: m.householdId }}
                  className="block min-h-16 px-4 py-3"
                >
                  <p className="font-medium">{m.name}</p>
                  <p className="mt-0.5 font-mono text-xs text-muted">
                    {memberDisplayCode(m.householdCode, m.beneficiaryId)}
                  </p>
                  <p className="mt-1 text-xs text-muted">
                    {m.relationship || "—"} · {m.gender || "—"}
                    {age !== null ? ` · ${age} yrs` : ""}
                  </p>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
