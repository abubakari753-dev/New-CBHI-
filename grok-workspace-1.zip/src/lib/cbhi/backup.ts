import { db, ensureDb } from "./db";
import { DEFAULT_SETTINGS, SHINILE_KEBELES, type HouseholdRecord, type KebeleRecord, type MemberRecord, type RegistrySettings } from "./types";
import { downloadBlob } from "./excel";

export type BackupFile = {
  version: 1;
  exportedAt: string;
  settings: RegistrySettings;
  kebeles: KebeleRecord[];
  households: HouseholdRecord[];
  members: MemberRecord[];
};

export async function createBackup(): Promise<BackupFile> {
  await ensureDb();
  const [settingsRow, kebeles, households, members] = await Promise.all([
    db.meta.get("settings"),
    db.kebeles.toArray(),
    db.households.toArray(),
    db.members.toArray(),
  ]);
  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    settings: (settingsRow?.value as RegistrySettings | undefined) ?? DEFAULT_SETTINGS,
    kebeles,
    households,
    members,
  };
}

export async function downloadBackup() {
  const backup = await createBackup();
  const blob = new Blob([JSON.stringify(backup)], { type: "application/json" });
  const stamp = new Date().toISOString().slice(0, 10);
  downloadBlob(blob, `cbhi-backup-${stamp}.json`);
}

export async function restoreBackup(file: File): Promise<{ households: number; members: number }> {
  const text = await file.text();
  const data = JSON.parse(text) as BackupFile;
  if (!data || data.version !== 1 || !Array.isArray(data.households) || !Array.isArray(data.members)) {
    throw new Error("This file is not a CBHI Registry backup.");
  }
  await ensureDb();
  await db.transaction("rw", db.households, db.members, db.kebeles, db.meta, async () => {
    await db.households.clear();
    await db.members.clear();
    await db.kebeles.clear();
    if (data.settings) await db.meta.put({ key: "settings", value: data.settings });
    await db.kebeles.bulkPut(data.kebeles?.length ? data.kebeles : SHINILE_KEBELES);
    const chunk = 400;
    for (let i = 0; i < data.households.length; i += chunk) {
      await db.households.bulkPut(data.households.slice(i, i + chunk));
    }
    for (let i = 0; i < data.members.length; i += chunk) {
      await db.members.bulkPut(data.members.slice(i, i + chunk));
    }
  });
  return { households: data.households.length, members: data.members.length };
}
