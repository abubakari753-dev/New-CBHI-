import { E as toMemberRecord, T as toHouseholdRecord, b as padBeneficiary, m as ensureDb, u as db, x as padKebele } from "./use-registry-DwO4lW8R.mjs";
import { i as parseLooseInt } from "./format-Crs6fxee.mjs";
import { n as strFromU8, t as gunzipSync } from "../_libs/fflate.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/seed-DSE7o0OK.js
function asScheme(value) {
	return value?.toUpperCase() === "I" ? "I" : "P";
}
function asGender(value) {
	const t = (value ?? "").trim().toLowerCase();
	if (t === "female" || t === "f") return "Female";
	if (t === "male" || t === "m") return "Male";
	return "";
}
function asScale(value) {
	if (value === "Higher" || value === "Middle" || value === "Lower") return value;
	return "";
}
function asSettlement(value) {
	if (value === "Rural" || value === "Town") return value;
	return "";
}
async function loadSeedGzip() {
	const res = await fetch("/seed/shinile-2017.json.gz");
	if (!res.ok) throw new Error("Could not load the 2017 Shinile seed file.");
	const buf = new Uint8Array(await res.arrayBuffer());
	const json = strFromU8(gunzipSync(buf));
	return JSON.parse(json);
}
async function importSeed(seed, onProgress) {
	await ensureDb();
	const households = seed.households ?? [];
	const total = households.length;
	const hhRows = [];
	const memberRows = [];
	for (const raw of households) {
		const code = String(raw.c ?? "").trim().toUpperCase();
		if (!code) continue;
		const members = raw.m ?? [];
		const head = members.find((m) => m.r === "Household Head") ?? members[0];
		const input = {
			scheme: asScheme(raw.s),
			kebeleName: String(raw.k ?? "").trim(),
			kebeleCode: padKebele(raw.kc ?? ""),
			gote: String(raw.gote ?? "").trim(),
			slidingScale: asScale(raw.ss),
			settlement: asSettlement(raw.st),
			hasCard: Boolean(raw.card),
			enroll: {
				day: parseLooseInt(raw.e?.[0]),
				month: parseLooseInt(raw.e?.[1]),
				year: parseLooseInt(raw.e?.[2])
			}
		};
		const names = members.map((m) => m.n);
		const hh = toHouseholdRecord(code, input, head?.n ?? "", members.length, names);
		hhRows.push(hh);
		for (const m of members) {
			const memberInput = {
				name: String(m.n ?? "").trim(),
				gender: asGender(m.g),
				dob: {
					day: parseLooseInt(m.d?.[0]),
					month: parseLooseInt(m.d?.[1]),
					year: parseLooseInt(m.d?.[2])
				},
				relationship: String(m.r ?? "").trim(),
				profession: String(m.p ?? "").trim(),
				beneficiaryId: padBeneficiary(m.b ?? "00")
			};
			memberRows.push(toMemberRecord(hh.id, hh.code, memberInput));
		}
	}
	const kebeles = (seed.kebeles ?? []).map((k) => ({
		code: padKebele(k.code),
		name: k.name
	}));
	const chunk = 400;
	await db.transaction("rw", db.households, db.members, db.kebeles, db.meta, async () => {
		await db.households.clear();
		await db.members.clear();
		if (kebeles.length) {
			await db.kebeles.clear();
			await db.kebeles.bulkPut(kebeles);
		}
		for (let i = 0; i < hhRows.length; i += chunk) {
			await db.households.bulkPut(hhRows.slice(i, i + chunk));
			onProgress?.(Math.min(i + chunk, hhRows.length), total);
		}
		for (let i = 0; i < memberRows.length; i += chunk) await db.members.bulkPut(memberRows.slice(i, i + chunk));
		if (seed.meta) {
			const prev = (await db.meta.get("settings"))?.value;
			await db.meta.put({
				key: "settings",
				value: {
					region: seed.meta.region ?? prev?.region ?? "Somali",
					zone: seed.meta.zone ?? prev?.zone ?? "Sitti",
					woreda: seed.meta.woreda ?? prev?.woreda ?? "Shinile",
					regionCode: seed.meta.regionCode ?? prev?.regionCode ?? "05",
					zoneCode: seed.meta.zoneCode ?? prev?.zoneCode ?? "04",
					woredaCode: seed.meta.woredaCode ?? prev?.woredaCode ?? "09"
				}
			});
		}
		await db.meta.put({
			key: "seededAt",
			value: Date.now()
		});
	});
	onProgress?.(total, total);
	return {
		households: hhRows.length,
		members: memberRows.length
	};
}
//#endregion
export { loadSeedGzip as n, importSeed as t };
