import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { HouseholdFields, emptyHousehold } from "@/components/household-fields";
import { MemberFields, emptyMember } from "@/components/member-fields";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { bumpRegistry, useDbReady, useKebeles } from "@/hooks/use-registry";
import { createHousehold } from "@/lib/cbhi/queries";
import type { HouseholdInput, MemberInput } from "@/lib/cbhi/types";

export const Route = createFileRoute("/households/new")({
  component: NewHouseholdPage,
});

function NewHouseholdPage() {
  const { ready } = useDbReady();
  const kebeles = useKebeles();
  const navigate = useNavigate();
  const [hh, setHh] = useState<HouseholdInput>(emptyHousehold);
  const [head, setHead] = useState<MemberInput>(emptyMember("Household Head"));
  const [saving, setSaving] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!hh.kebeleCode) {
      toast.error("Select a kebele");
      return;
    }
    if (!head.name.trim()) {
      toast.error("Household head name is required");
      return;
    }
    if (!head.gender) {
      toast.error("Select gender");
      return;
    }
    setSaving(true);
    try {
      const kebele = kebeles.find((k) => k.code === hh.kebeleCode);
      const created = await createHousehold(
        { ...hh, kebeleName: kebele?.name ?? hh.kebeleName },
        { ...head, relationship: "Household Head" },
      );
      bumpRegistry();
      toast.success(`Registered ${created.code}`);
      await navigate({ to: "/households/$id", params: { id: created.id } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save household");
    } finally {
      setSaving(false);
    }
  };

  if (!ready) return <p className="py-16 text-center text-sm text-muted">Opening registry…</p>;

  return (
    <form onSubmit={submit} className="pb-8">
      <PageHeader title="Register household" subtitle="A unique CBHI ID is assigned on save." />
      <section className="rounded-[24px] border border-border bg-surface p-5 shadow-card">
        <h2 className="mb-4 text-sm font-semibold">Household</h2>
        <HouseholdFields value={hh} onChange={setHh} kebeles={kebeles} />
      </section>
      <section className="mt-4 rounded-[24px] border border-border bg-surface p-5 shadow-card">
        <h2 className="mb-4 text-sm font-semibold">Household head</h2>
        <MemberFields value={head} onChange={setHead} lockHead />
      </section>
      <Button type="submit" className="mt-5 w-full" size="lg" disabled={saving}>
        {saving ? "Saving…" : "Save household"}
      </Button>
    </form>
  );
}
