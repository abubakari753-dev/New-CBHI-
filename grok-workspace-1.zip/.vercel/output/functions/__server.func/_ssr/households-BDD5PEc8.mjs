import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as ChevronRight, o as Search } from "../_libs/lucide-react.mjs";
import { r as Route$2 } from "./router-b6X6bWYl.mjs";
import { A as useDbReady, C as scaleTone, M as useKebeles, j as useHouseholdList, n as EmptyState, r as PageHeader } from "./use-registry-DwO4lW8R.mjs";
import { n as Input, r as Select } from "./input-BZ_a7Ma_.mjs";
import { t as Badge } from "./badge-DmolU3Bu.mjs";
import { t as useVirtualizer } from "../_libs/@tanstack/react-virtual+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/households-BDD5PEc8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HouseholdsPage() {
	const { ready } = useDbReady();
	const { q, kebele } = Route$2.useSearch();
	const navigate = Route$2.useNavigate();
	const kebeles = useKebeles();
	const [scale, setScale] = (0, import_react.useState)("all");
	const [settlement, setSettlement] = (0, import_react.useState)("all");
	const filters = (0, import_react.useMemo)(() => ({
		q: q ?? "",
		kebeleCode: kebele ?? "",
		slidingScale: scale,
		settlement,
		scheme: "all"
	}), [
		q,
		kebele,
		scale,
		settlement
	]);
	const { rows } = useHouseholdList(filters);
	const parentRef = (0, import_react.useRef)(null);
	const virtualizer = useVirtualizer({
		count: rows?.length ?? 0,
		getScrollElement: () => parentRef.current,
		estimateSize: () => 88,
		overscan: 10
	});
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Opening registry…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Households",
				subtitle: rows ? `${rows.length.toLocaleString()} records` : "Searching…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 grid gap-2 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-3.5 left-3 size-4 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q ?? "",
						onChange: (e) => navigate({ search: (prev) => ({
							...prev,
							q: e.target.value || void 0
						}) }),
						placeholder: "Search name, ID, kebele",
						className: "pl-9"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: kebele ?? "",
					onChange: (e) => navigate({ search: (prev) => ({
						...prev,
						kebele: e.target.value || void 0
					}) }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "All kebeles"
					}), kebeles.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k.code,
						children: k.name
					}, k.code))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: scale,
					onChange: (e) => setScale(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All categories"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Higher",
							children: "Higher"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Middle",
							children: "Middle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Lower",
							children: "Lower"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: settlement,
					onChange: (e) => setSettlement(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Rural and town"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Rural",
							children: "Rural"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Town",
							children: "Town"
						})
					]
				})]
			}),
			!rows ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-muted",
				children: "Loading households…"
			}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "No matching households",
				body: "Try another kebele or register a new household.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/households/new",
					className: "text-sm font-medium text-primary",
					children: "Register household"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: parentRef,
				className: "h-[min(70vh,720px)] overflow-auto rounded-[20px] border border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						height: virtualizer.getTotalSize(),
						position: "relative"
					},
					children: virtualizer.getVirtualItems().map((item) => {
						const hh = rows[item.index];
						if (!hh) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0",
							style: {
								height: item.size,
								transform: `translateY(${item.start}px)`
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/households/$id",
								params: { id: hh.id },
								className: "flex min-h-[88px] items-center justify-between gap-3 border-b border-border px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate font-medium",
											children: hh.headName || "Unnamed head"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 truncate font-mono text-xs text-muted",
											children: hh.code
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-xs text-muted",
											children: [
												hh.kebeleName,
												" · ",
												hh.memberCount,
												" member",
												hh.memberCount === 1 ? "" : "s"
											]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 items-center gap-2",
									children: [hh.slidingScale ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: scaleTone(hh.slidingScale),
										children: hh.slidingScale
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-subtle" })]
								})]
							})
						}, hh.id);
					})
				})
			})
		]
	});
}
//#endregion
export { HouseholdsPage as component };
