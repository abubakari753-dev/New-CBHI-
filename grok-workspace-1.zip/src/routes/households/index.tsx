import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { ChevronRight, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input, Select } from "@/components/ui/input";
import { EmptyState, PageHeader, scaleTone } from "@/components/page-header";
import { useDbReady, useHouseholdList, useKebeles } from "@/hooks/use-registry";
import type { HouseholdFilters, Settlement, SlidingScale } from "@/lib/cbhi/types";

type Search = { q?: string; kebele?: string };

export const Route = createFileRoute("/households/")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    q: typeof search.q === "string" ? search.q : undefined,
    kebele: typeof search.kebele === "string" ? search.kebele : undefined,
  }),
  component: HouseholdsPage,
});

function HouseholdsPage() {
  const { ready } = useDbReady();
  const { q, kebele } = Route.useSearch();
  const navigate = Route.useNavigate();
  const kebeles = useKebeles();
  const [scale, setScale] = useState<SlidingScale | "all">("all");
  const [settlement, setSettlement] = useState<Settlement | "all">("all");
  const filters: HouseholdFilters = useMemo(
    () => ({
      q: q ?? "",
      kebeleCode: kebele ?? "",
      slidingScale: scale,
      settlement,
      scheme: "all",
    }),
    [q, kebele, scale, settlement],
  );
  const { rows } = useHouseholdList(filters);
  const parentRef = useRef<HTMLDivElement>(null);
  const virtualizer = useVirtualizer({
    count: rows?.length ?? 0,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 88,
    overscan: 10,
  });

  if (!ready) return <p className="py-16 text-center text-sm text-muted">Opening registry…</p>;

  return (
    <div className="flex flex-col">
      <PageHeader title="Households" subtitle={rows ? `${rows.length.toLocaleString()} records` : "Searching…"} />

      <div className="mb-3 grid gap-2 sm:grid-cols-2">
        <div className="relative">
          <Search className="pointer-events-none absolute top-3.5 left-3 size-4 text-subtle" />
          <Input
            value={q ?? ""}
            onChange={(e) => navigate({ search: (prev) => ({ ...prev, q: e.target.value || undefined }) })}
            placeholder="Search name, ID, kebele"
            className="pl-9"
          />
        </div>
        <Select
          value={kebele ?? ""}
          onChange={(e) => navigate({ search: (prev) => ({ ...prev, kebele: e.target.value || undefined }) })}
        >
          <option value="">All kebeles</option>
          {kebeles.map((k) => (
            <option key={k.code} value={k.code}>
              {k.name}
            </option>
          ))}
        </Select>
      </div>
      <div className="mb-4 grid grid-cols-2 gap-2">
        <Select value={scale} onChange={(e) => setScale(e.target.value as SlidingScale | "all")}>
          <option value="all">All categories</option>
          <option value="Higher">Higher</option>
          <option value="Middle">Middle</option>
          <option value="Lower">Lower</option>
        </Select>
        <Select value={settlement} onChange={(e) => setSettlement(e.target.value as Settlement | "all")}>
          <option value="all">Rural and town</option>
          <option value="Rural">Rural</option>
          <option value="Town">Town</option>
        </Select>
      </div>

      {!rows ? (
        <p className="py-10 text-center text-sm text-muted">Loading households…</p>
      ) : rows.length === 0 ? (
        <EmptyState
          title="No matching households"
          body="Try another kebele or register a new household."
          action={
            <Link to="/households/new" className="text-sm font-medium text-primary">
              Register household
            </Link>
          }
        />
      ) : (
        <div ref={parentRef} className="h-[min(70vh,720px)] overflow-auto rounded-[20px] border border-border bg-surface">
          <div style={{ height: virtualizer.getTotalSize(), position: "relative" }}>
            {virtualizer.getVirtualItems().map((item) => {
              const hh = rows[item.index];
              if (!hh) return null;
              return (
                <div
                  key={hh.id}
                  className="absolute inset-x-0"
                  style={{ height: item.size, transform: `translateY(${item.start}px)` }}
                >
                  <Link
                    to="/households/$id"
                    params={{ id: hh.id }}
                    className="flex min-h-[88px] items-center justify-between gap-3 border-b border-border px-4 py-3"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-medium">{hh.headName || "Unnamed head"}</p>
                      <p className="mt-0.5 truncate font-mono text-xs text-muted">{hh.code}</p>
                      <p className="mt-1 text-xs text-muted">
                        {hh.kebeleName} · {hh.memberCount} member{hh.memberCount === 1 ? "" : "s"}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      {hh.slidingScale ? <Badge tone={scaleTone(hh.slidingScale)}>{hh.slidingScale}</Badge> : null}
                      <ChevronRight className="size-4 text-subtle" />
                    </div>
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
