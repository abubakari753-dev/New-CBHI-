import { gunzipSync, strFromU8 } from "fflate";
import { db, ensureDb, toHouseholdRecord, toMemberRecord } from "./db";
import { codeToId, padBeneficiary, padKebele } from "./ids";
import { parseLooseInt } from "./format";
import type { Gender, HouseholdInput, HouseholdRecord, MemberInput, MemberRecord, Scheme, Settlement, SlidingScale } from "./types";

type SeedMember = {
  n: string;
  b: string;
  g?: string;
  d?: number[];
  r?: string;
  p?: string;
};

type SeedHousehold = {
  c: string;
  s?: string;
  k?: string;
  kc?: string;
  gote?: string;
  ss?: string;
  st?: string;
  card?: boolean;
  e?: number[];
  m: SeedMember[];
};

type SeedFile = {
  meta?: {
    region?: string;
    zone?: string;
    woreda?: string;
    regionCode?: string;
    zoneCode?: string;
    woredaCode?: string;
  };
  kebeles?: { name: string; code: string }[];
  households: SeedHousehold[];
};

function asScheme(value: string | undefined): Scheme {
  return value?.toUpperCase() === "I" ? "I" : "P";
}

function asGender(value: string | undefined): Gender {
  const t = (value ?? "").trim().toLowerCase();
  if (t === "female" || t === "f") return "Female";
  if (t === "male" || t === "m") return "Male";
  return "";
}

function asScale(value: string | undefined): SlidingScale {
  if (value === "Higher" || value === "Middle" || value === "Lower") return value;
  return "";
}

function asSettlement(value: string | undefined): Settlement {
  if (value === "Rural" || value === "Town") return value;
  return "";
}

export async function loadSeedGzip(): Promise<SeedFile> {
  const res = await fetch("/seed/shinile-2017.json.gz");
  if (!res.ok) throw new Error("Could not load the 2017 Shinile seed file.");
  const buf = new Uint8Array(await res.arrayBuffer());
  const json = strFromU8(gunzipSync(buf));
  return JSON.parse(json) as SeedFile;
}

export async function importSeed(
  seed: SeedFile,
  onProgress?: (done: number, total: number) => void,
): Promise<{ households: number; members: number }> {
  await ensureDb();
  const households = seed.households ?? [];
  const total = households.length;
  const hhRows: HouseholdRecord[] = [];
  const memberRows: MemberRecord[] = [];

  for (const raw of households) {
    const code = String(raw.c ?? "").trim().toUpperCase();
    if (!code) continue;
    const members = raw.m ?? [];
    const head = members.find((m) => m.r === "Household Head") ?? members[0];
    const input: HouseholdInput = {
      scheme: asScheme(raw.s),
      kebeleName: String(raw.k ?? "").trim(),
      kebeleCode: padKebele(raw.kc ?? ""),
      gote: String(raw.gote ?? "").trim(),
      slidingScale: asScale(raw.ss),
      settlement: asSettlement(raw.st),
      hasCard: Boolean(raw.card),
      enroll: {
        day: parseLooseInt(raw.e?.[0]),
        month: parseLooseInt(raw.e?.[1]),
        year: parseLooseInt(raw.e?.[2]),
      },
    };
    const names = members.map((m) => m.n);
    const hh = toHouseholdRecord(code, input, head?.n ?? "", members.length, names);
    hhRows.push(hh);
    for (const m of members) {
      const memberInput: MemberInput = {
        name: String(m.n ?? "").trim(),
        gender: asGender(m.g),
        dob: {
          day: parseLooseInt(m.d?.[0]),
          month: parseLooseInt(m.d?.[1]),
          year: parseLooseInt(m.d?.[2]),
        },
        relationship: String(m.r ?? "").trim(),
        profession: String(m.p ?? "").trim(),
        beneficiaryId: padBeneficiary(m.b ?? "00"),
      };
      memberRows.push(toMemberRecord(hh.id, hh.code, memberInput));
    }
  }

  const kebeles = (seed.kebeles ?? []).map((k) => ({
    code: padKebele(k.code),
    name: k.name,
  }));

  const chunk = 400;
  await db.transaction("rw", db.households, db.members, db.kebeles, db.meta, async () => {
    await db.households.clear();
    await db.members.clear();
    if (kebeles.length) {
      await db.kebeles.clear();
      await db.kebeles.bulkPut(kebeles);
    }
    for (let i = 0; i < hhRows.length; i += chunk) {
      await db.households.bulkPut(hhRows.slice(i, i + chunk));
      onProgress?.(Math.min(i + chunk, hhRows.length), total);
    }
    for (let i = 0; i < memberRows.length; i += chunk) {
      await db.members.bulkPut(memberRows.slice(i, i + chunk));
    }
    if (seed.meta) {
      const prev = (await db.meta.get("settings"))?.value as Record<string, string> | undefined;
      await db.meta.put({
        key: "settings",
        value: {
          region: seed.meta.region ?? prev?.region ?? "Somali",
          zone: seed.meta.zone ?? prev?.zone ?? "Sitti",
          woreda: seed.meta.woreda ?? prev?.woreda ?? "Shinile",
          regionCode: seed.meta.regionCode ?? prev?.regionCode ?? "05",
          zoneCode: seed.meta.zoneCode ?? prev?.zoneCode ?? "04",
          woredaCode: seed.meta.woredaCode ?? prev?.woredaCode ?? "09",
        },
      });
    }
    await db.meta.put({ key: "seededAt", value: Date.now() });
  });

  onProgress?.(total, total);
  return { households: hhRows.length, members: memberRows.length };
}

export function emptySeedProgress() {
  return { done: 0, total: 0 };
}

export { codeToId };
