import Dexie, { type EntityTable } from "dexie";
import {
  DEFAULT_SETTINGS,
  SHINILE_KEBELES,
  type HouseholdInput,
  type HouseholdRecord,
  type KebeleRecord,
  type MemberInput,
  type MemberRecord,
  type RegistrySettings,
  type Scheme,
} from "./types";
import { codeToId, memberKey, padBeneficiary, searchBlob } from "./ids";

type MetaRecord = { key: string; value: unknown };

class CbhiDatabase extends Dexie {
  households!: EntityTable<HouseholdRecord, "id">;
  members!: EntityTable<MemberRecord, "id">;
  kebeles!: EntityTable<KebeleRecord, "code">;
  meta!: EntityTable<MetaRecord, "key">;

  constructor() {
    super("cbhi-registry-v1");
    this.version(1).stores({
      households: "id, code, kebeleCode, kebeleName, slidingScale, settlement, scheme, headName, updatedAt",
      members: "id, householdId, householdCode, beneficiaryId, name, gender, relationship",
      kebeles: "code, name",
      meta: "key",
    });
  }
}

export const db = new CbhiDatabase();

export async function ensureDb(): Promise<void> {
  await db.open();
  const settings = await db.meta.get("settings");
  if (!settings) {
    await db.meta.put({ key: "settings", value: DEFAULT_SETTINGS });
  }
  const kebeleCount = await db.kebeles.count();
  if (kebeleCount === 0) {
    await db.kebeles.bulkPut(SHINILE_KEBELES);
  }
}

export async function getSettings(): Promise<RegistrySettings> {
  const row = await db.meta.get("settings");
  return { ...DEFAULT_SETTINGS, ...((row?.value as RegistrySettings | undefined) ?? {}) };
}

export async function saveSettings(next: RegistrySettings): Promise<void> {
  await db.meta.put({ key: "settings", value: next });
}

export function buildHouseholdSearch(
  hh: Pick<HouseholdRecord, "code" | "kebeleName" | "kebeleCode" | "gote" | "headName">,
  memberNames: string[],
): string {
  return searchBlob(hh.code, hh.kebeleName, hh.kebeleCode, hh.gote, hh.headName, ...memberNames);
}

export function toMemberRecord(
  householdId: string,
  householdCode: string,
  input: MemberInput,
): MemberRecord {
  const beneficiaryId = padBeneficiary(input.beneficiaryId ?? "00");
  const name = input.name.trim();
  return {
    id: memberKey(householdId, beneficiaryId),
    householdId,
    householdCode,
    beneficiaryId,
    name,
    gender: input.gender,
    dobDay: input.dob.day,
    dobMonth: input.dob.month,
    dobYear: input.dob.year,
    relationship: input.relationship,
    profession: input.profession,
    search: searchBlob(name, householdCode, beneficiaryId, input.relationship, input.profession),
  };
}

export function toHouseholdRecord(
  code: string,
  input: HouseholdInput,
  headName: string,
  memberCount: number,
  memberNames: string[],
): HouseholdRecord {
  const id = codeToId(code);
  const rec: HouseholdRecord = {
    id,
    code: code.toUpperCase(),
    scheme: input.scheme,
    kebeleName: input.kebeleName,
    kebeleCode: input.kebeleCode,
    gote: input.gote.trim(),
    slidingScale: input.slidingScale,
    settlement: input.settlement,
    hasCard: input.hasCard,
    enrollDay: input.enroll.day,
    enrollMonth: input.enroll.month,
    enrollYear: input.enroll.year,
    headName,
    memberCount,
    search: "",
    updatedAt: Date.now(),
  };
  rec.search = buildHouseholdSearch(rec, memberNames);
  return rec;
}

export async function refreshHouseholdDerived(householdId: string): Promise<void> {
  const hh = await db.households.get(householdId);
  if (!hh) return;
  const members = await db.members.where("householdId").equals(householdId).toArray();
  members.sort((a, b) => a.beneficiaryId.localeCompare(b.beneficiaryId));
  const head =
    members.find((m) => m.relationship === "Household Head") ?? members[0];
  hh.headName = head?.name ?? "";
  hh.memberCount = members.length;
  hh.search = buildHouseholdSearch(
    hh,
    members.map((m) => m.name),
  );
  hh.updatedAt = Date.now();
  await db.households.put(hh);
}

export async function nextBeneficiaryId(householdId: string): Promise<string> {
  const members = await db.members.where("householdId").equals(householdId).toArray();
  let max = -1;
  for (const m of members) {
    const n = Number.parseInt(m.beneficiaryId, 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return padBeneficiary(max + 1);
}

export async function listCodesForKebele(scheme: Scheme, kebeleCode: string): Promise<string[]> {
  const rows = await db.households.where("kebeleCode").equals(kebeleCode).toArray();
  return rows.filter((r) => r.scheme === scheme).map((r) => r.code);
}
