import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { HouseholdFields } from "@/components/household-fields";
import { MemberFields, emptyMember } from "@/components/member-fields";
import { PageHeader, scaleTone } from "@/components/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { bumpRegistry, useDbReady, useKebeles, useRegistryTick } from "@/hooks/use-registry";
import { ageFromDob, formatDate } from "@/lib/cbhi/format";
import { memberDisplayCode } from "@/lib/cbhi/ids";
import {
  addMember,
  deleteHousehold,
  deleteMember,
  getHousehold,
  getHouseholdMembers,
  updateHousehold,
  updateMember,
} from "@/lib/cbhi/queries";
import type { HouseholdInput, HouseholdRecord, MemberInput, MemberRecord } from "@/lib/cbhi/types";

export const Route = createFileRoute("/households/$id")({
  component: HouseholdDetailPage,
});

function HouseholdDetailPage() {
  const { id } = Route.useParams();
  const { ready } = useDbReady();
  const tick = useRegistryTick();
  const kebeles = useKebeles();
  const navigate = useNavigate();
  const [hh, setHh] = useState<HouseholdRecord | null | undefined>(undefined);
  const [members, setMembers] = useState<MemberRecord[]>([]);
  const [editingHh, setEditingHh] = useState(false);
  const [hhForm, setHhForm] = useState<HouseholdInput | null>(null);
  const [memberForm, setMemberForm] = useState<MemberInput | null>(null);
  const [editingMemberId, setEditingMemberId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!ready) return;
    getHousehold(id).then(setHh);
    getHouseholdMembers(id).then(setMembers);
  }, [id, ready, tick]);

  if (!ready || hh === undefined) {
    return <p className="py-16 text-center text-sm text-muted">Loading household…</p>;
  }
  if (!hh) {
    return <p className="py-16 text-center text-sm text-muted">Household not found.</p>;
  }

  const openNewMember = () => {
    setEditingMemberId(null);
    setMemberForm(emptyMember("Son"));
  };

  const openEditMember = (m: MemberRecord) => {
    setEditingMemberId(m.id);
    setMemberForm({
      name: m.name,
      gender: m.gender,
      dob: { day: m.dobDay, month: m.dobMonth, year: m.dobYear },
      relationship: m.relationship || "Other",
      profession: m.profession,
      beneficiaryId: m.beneficiaryId,
    });
  };

  const saveHousehold = async () => {
    if (!hhForm) return;
    setBusy(true);
    try {
      await updateHousehold(hh.id, hhForm);
      bumpRegistry();
      setEditingHh(false);
      toast.success("Household updated");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Update failed");
    } finally {
      setBusy(false);
    }
  };

  const saveMember = async () => {
    if (!memberForm || !memberForm.name.trim()) {
      toast.error("Name is required");
      return;
    }
    setBusy(true);
    try {
      if (editingMemberId) await updateMember(editingMemberId, memberForm);
      else await addMember(hh.id, memberForm);
      bumpRegistry();
      setMemberForm(null);
      toast.success(editingMemberId ? "Member updated" : "Member added");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save member");
    } finally {
      setBusy(false);
    }
  };

  const removeMember = async (m: MemberRecord) => {
    if (!confirm(`Remove ${m.name}?`)) return;
    try {
      await deleteMember(m.id);
      bumpRegistry();
      toast.success("Member removed");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not delete");
    }
  };

  const removeHousehold = async () => {
    if (!confirm(`Delete household ${hh.code} and all members? This cannot be undone.`)) return;
    await deleteHousehold(hh.id);
    bumpRegistry();
    toast.success("Household deleted");
    await navigate({ to: "/households" });
  };

  return (
    <div className="pb-8">
      <PageHeader
        title={hh.headName || "Household"}
        subtitle={hh.code}
        action={
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setHhForm({
                scheme: hh.scheme,
                kebeleName: hh.kebeleName,
                kebeleCode: hh.kebeleCode,
                gote: hh.gote,
                slidingScale: hh.slidingScale,
                settlement: hh.settlement,
                hasCard: hh.hasCard,
                enroll: { day: hh.enrollDay, month: hh.enrollMonth, year: hh.enrollYear },
              });
              setEditingHh(true);
            }}
          >
            <Pencil className="size-4" />
            Edit
          </Button>
        }
      />

      <div className="flex flex-wrap gap-2">
        <Badge tone="primary">{hh.kebeleName}</Badge>
        {hh.slidingScale ? <Badge tone={scaleTone(hh.slidingScale)}>{hh.slidingScale}</Badge> : null}
        {hh.settlement ? <Badge>{hh.settlement}</Badge> : null}
        <Badge tone={hh.hasCard ? "primary" : "muted"}>{hh.hasCard ? "ID card" : "No card"}</Badge>
        <Badge>{hh.scheme === "I" ? "Indigent" : "Paying"}</Badge>
      </div>

      <dl className="mt-5 grid grid-cols-2 gap-3 rounded-[20px] border border-border bg-surface p-4 text-sm">
        <div>
          <dt className="text-xs text-muted">Gote</dt>
          <dd className="font-medium">{hh.gote || "—"}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Enrolled</dt>
          <dd className="font-medium">{formatDate({ day: hh.enrollDay, month: hh.enrollMonth, year: hh.enrollYear })}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Members</dt>
          <dd className="font-medium tabular">{hh.memberCount}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted">Kebele code</dt>
          <dd className="font-mono font-medium">{hh.kebeleCode}</dd>
        </div>
      </dl>

      <div className="mt-6 flex items-center justify-between">
        <h2 className="text-sm font-semibold">Members</h2>
        <Button size="sm" onClick={openNewMember}>
          <Plus className="size-4" />
          Add member
        </Button>
      </div>
      <ul className="mt-3 overflow-hidden rounded-[20px] border border-border bg-surface">
        {members.map((m) => {
          const age = ageFromDob(m.dobYear);
          return (
            <li key={m.id} className="flex items-start justify-between gap-3 border-b border-border px-4 py-3 last:border-b-0">
              <div className="min-w-0">
                <p className="font-medium">{m.name}</p>
                <p className="mt-0.5 font-mono text-xs text-muted">{memberDisplayCode(hh.code, m.beneficiaryId)}</p>
                <p className="mt-1 text-xs text-muted">
                  {m.relationship || "—"} · {m.gender || "—"}
                  {age !== null ? ` · ${age} yrs` : ""}
                  {m.profession ? ` · ${m.profession}` : ""}
                </p>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" onClick={() => openEditMember(m)} aria-label="Edit member">
                  <Pencil className="size-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => removeMember(m)} aria-label="Delete member">
                  <Trash2 className="size-4 text-danger" />
                </Button>
              </div>
            </li>
          );
        })}
      </ul>

      <Button variant="outline" className="mt-6 w-full text-danger" onClick={removeHousehold}>
        Delete household
      </Button>

      <Dialog open={editingHh} onOpenChange={setEditingHh}>
        <DialogContent title="Edit household">
          {hhForm ? (
            <div className="grid gap-4">
              <HouseholdFields value={hhForm} onChange={setHhForm} kebeles={kebeles} />
              <Button onClick={saveHousehold} disabled={busy}>
                Save changes
              </Button>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={!!memberForm} onOpenChange={(open) => !open && setMemberForm(null)}>
        <DialogContent title={editingMemberId ? "Edit member" : "Add member"}>
          {memberForm ? (
            <div className="grid gap-4">
              <MemberFields
                value={memberForm}
                onChange={setMemberForm}
                lockHead={memberForm.relationship === "Household Head"}
              />
              <Button onClick={saveMember} disabled={busy}>
                {editingMemberId ? "Save member" : "Add member"}
              </Button>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
