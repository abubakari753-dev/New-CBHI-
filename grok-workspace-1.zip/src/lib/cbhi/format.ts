import type { PartialDate } from "./types";

export function formatDate(date: PartialDate | { day: number | null; month: number | null; year: number | null }): string {
  const day = date.day;
  const month = date.month;
  const year = date.year;
  if (!day && !month && !year) return "—";
  const dd = day ? String(day).padStart(2, "0") : "??";
  const mm = month ? String(month).padStart(2, "0") : "??";
  const yyyy = year ? String(year) : "????";
  return `${dd}/${mm}/${yyyy}`;
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-US").format(n);
}

export function titleCase(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function ageFromDob(year: number | null, now = new Date()): number | null {
  if (!year || year < 1800 || year > now.getFullYear() + 1) return null;
  const age = now.getFullYear() - year;
  if (age < 0 || age > 130) return null;
  return age;
}

export function parseLooseInt(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const n = typeof value === "number" ? value : Number.parseInt(String(value).trim(), 10);
  if (!Number.isFinite(n)) return null;
  return Math.trunc(n);
}

export function yesNo(value: boolean): string {
  return value ? "Yes" : "No";
}
