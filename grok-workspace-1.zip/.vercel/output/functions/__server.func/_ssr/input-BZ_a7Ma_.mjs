import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as cn } from "./router-b6X6bWYl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-BZ_a7Ma_.js
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "h-11 w-full rounded-[12px] border border-border bg-surface px-3 text-base text-fg placeholder:text-subtle shadow-none";
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(fieldClass, className),
		...props
	});
}
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(fieldClass, "appearance-none pr-8", className),
		...props,
		children
	});
}
function Field({ label, am, required, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm font-medium text-fg",
				children: [label, required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-danger",
					children: " *"
				}) : null]
			}),
			am ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "-mt-0.5 text-xs text-muted",
				children: am
			}) : null,
			children
		]
	});
}
//#endregion
export { Input as n, Select as r, Field as t };
