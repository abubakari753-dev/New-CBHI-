import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/page-header";
import { bumpRegistry, useDbReady, useStats } from "@/hooks/use-registry";
import { downloadBackup, restoreBackup } from "@/lib/cbhi/backup";
import { downloadBlob, exportExcel, importExcelFile } from "@/lib/cbhi/excel";
import { formatNumber } from "@/lib/cbhi/format";
import { clearRegistry } from "@/lib/cbhi/queries";
import { importSeed, loadSeedGzip } from "@/lib/cbhi/seed";

export const Route = createFileRoute("/data")({
  component: DataPage,
});

function DataPage() {
  const { ready } = useDbReady();
  const stats = useStats();
  const excelRef = useRef<HTMLInputElement>(null);
  const backupRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);

  if (!ready) return <p className="py-16 text-center text-sm text-muted">Opening registry…</p>;

  const run = async (label: string, fn: () => Promise<void>) => {
    setBusy(label);
    try {
      await fn();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="pb-8">
      <PageHeader
        title="Data"
        subtitle={
          stats
            ? `${formatNumber(stats.households)} households · ${formatNumber(stats.members)} members on this device`
            : "Local IndexedDB store"
        }
      />

      <Section
        title="Excel"
        body="Import the original CBHI registration workbook, or export a clean sheet Excel can open."
      >
        <input
          ref={excelRef}
          type="file"
          accept=".xlsx,.xls"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            run("import", async () => {
              const result = await importExcelFile(file, "merge");
              bumpRegistry();
              toast.success(`Imported ${result.households.toLocaleString()} households`);
            });
          }}
        />
        <div className="grid gap-2 sm:grid-cols-2">
          <Button variant="outline" disabled={!!busy} onClick={() => excelRef.current?.click()}>
            {busy === "import" ? "Importing…" : "Import Excel"}
          </Button>
          <Button
            variant="outline"
            disabled={!!busy}
            onClick={() =>
              run("export", async () => {
                const blob = await exportExcel();
                downloadBlob(blob, `cbhi-export-${new Date().toISOString().slice(0, 10)}.xlsx`);
                toast.success("Excel downloaded");
              })
            }
          >
            {busy === "export" ? "Exporting…" : "Export Excel"}
          </Button>
        </div>
      </Section>

      <Section title="Backup" body="Full JSON snapshot of households, members, kebeles, and settings. Restore replaces the local database.">
        <input
          ref={backupRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            run("restore", async () => {
              const result = await restoreBackup(file);
              bumpRegistry();
              toast.success(`Restored ${result.households.toLocaleString()} households`);
            });
          }}
        />
        <div className="grid gap-2 sm:grid-cols-2">
          <Button
            variant="outline"
            disabled={!!busy}
            onClick={() =>
              run("backup", async () => {
                await downloadBackup();
                toast.success("Backup downloaded");
              })
            }
          >
            Download backup
          </Button>
          <Button variant="outline" disabled={!!busy} onClick={() => backupRef.current?.click()}>
            {busy === "restore" ? "Restoring…" : "Restore backup"}
          </Button>
        </div>
      </Section>

      <Section
        title="2017 Shinile database"
        body="Load the attached woreda census into this phone. This replaces current households."
      >
        <Button
          disabled={!!busy}
          onClick={() =>
            run("seed", async () => {
              if (!confirm("Replace the current registry with the 2017 Shinile database?")) return;
              const seed = await loadSeedGzip();
              const result = await importSeed(seed);
              bumpRegistry();
              toast.success(`Loaded ${result.households.toLocaleString()} households`);
            })
          }
        >
          {busy === "seed" ? "Loading…" : "Load 2017 Shinile data"}
        </Button>
      </Section>

      <Section
        title="Install on Android"
        body="This registry is a standalone app. In Chrome, open the browser menu and choose Add to Home screen or Install app. After that it opens full-screen, stores data on the phone, and works without a network."
      >
        <Button variant="secondary" asChild>
          <a href="/?install=1">Installation guide</a>
        </Button>
      </Section>

      <Section title="Danger zone" body="Clears households and members on this device. Kebeles and location settings are kept.">
        <Button
          variant="danger"
          disabled={!!busy}
          onClick={() =>
            run("clear", async () => {
              if (!confirm("Delete every household and member on this device?")) return;
              await clearRegistry();
              bumpRegistry();
              toast.success("Registry cleared");
            })
          }
        >
          Clear all records
        </Button>
      </Section>
    </div>
  );
}

function Section({ title, body, children }: { title: string; body: string; children: ReactNode }) {
  return (
    <section className="mb-4 rounded-[24px] border border-border bg-surface p-5 shadow-card">
      <h2 className="text-sm font-semibold">{title}</h2>
      <p className="mt-1 mb-4 text-sm text-muted">{body}</p>
      {children}
    </section>
  );
}
