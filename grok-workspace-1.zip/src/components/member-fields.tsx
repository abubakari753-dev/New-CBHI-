import { DateFields } from "@/components/date-fields";
import { Field, Input, Select } from "@/components/ui/input";
import { AM, GENDERS, PROFESSIONS, RELATIONSHIPS } from "@/lib/cbhi/lookups";
import type { MemberInput } from "@/lib/cbhi/types";

export function MemberFields({
  value,
  onChange,
  lockHead,
}: {
  value: MemberInput;
  onChange: (next: MemberInput) => void;
  lockHead?: boolean;
}) {
  return (
    <div className="grid gap-4">
      <Field label="Full name" am={AM.fullName} required>
        <Input
          value={value.name}
          onChange={(e) => onChange({ ...value, name: e.target.value })}
          placeholder="e.g. Fadumo Farax Abdi"
          autoComplete="name"
        />
      </Field>
      <Field label="Gender" am={AM.gender} required>
        <Select value={value.gender} onChange={(e) => onChange({ ...value, gender: e.target.value as MemberInput["gender"] })}>
          <option value="">Select</option>
          {GENDERS.map((g) => (
            <option key={g} value={g}>
              {g}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Date of birth" am={AM.dob}>
        <DateFields value={value.dob} onChange={(dob) => onChange({ ...value, dob })} />
      </Field>
      <Field label="Relationship" am={AM.relationship} required>
        <Select
          value={value.relationship}
          disabled={lockHead}
          onChange={(e) => onChange({ ...value, relationship: e.target.value })}
        >
          {RELATIONSHIPS.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </Select>
      </Field>
      <Field label="Profession" am={AM.profession}>
        <Select value={value.profession} onChange={(e) => onChange({ ...value, profession: e.target.value })}>
          <option value="">Select</option>
          {PROFESSIONS.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </Select>
      </Field>
    </div>
  );
}

export const emptyMember = (relationship = "Household Head"): MemberInput => ({
  name: "",
  gender: "",
  dob: { day: null, month: null, year: null },
  relationship,
  profession: "",
});
