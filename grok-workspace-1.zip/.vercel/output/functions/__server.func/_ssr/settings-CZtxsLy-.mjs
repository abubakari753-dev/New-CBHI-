import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-DAHYoAhQ.mjs";
import { A as useDbReady, S as saveSettings, _ as getSettings, f as deleteKebele, k as upsertKebele, r as PageHeader, s as bumpRegistry, v as listKebeles, x as padKebele } from "./use-registry-DwO4lW8R.mjs";
import { n as Input, t as Field } from "./input-BZ_a7Ma_.mjs";
import { t as AM } from "./lookups-ClUJLUOS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CZtxsLy-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const { ready } = useDbReady();
	const [settings, setSettings] = (0, import_react.useState)(null);
	const [kebeles, setKebeles] = (0, import_react.useState)([]);
	const [newName, setNewName] = (0, import_react.useState)("");
	const [newCode, setNewCode] = (0, import_react.useState)("");
	const reload = async () => {
		setSettings(await getSettings());
		setKebeles(await listKebeles());
	};
	(0, import_react.useEffect)(() => {
		if (ready) reload();
	}, [ready]);
	if (!ready || !settings) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Opening registry…"
	});
	const save = async () => {
		await saveSettings(settings);
		bumpRegistry();
		toast.success("Location saved");
	};
	const addKebele = async () => {
		if (!newName.trim()) {
			toast.error("Kebele name is required");
			return;
		}
		const code = padKebele(newCode || String(kebeles.reduce((m, k) => Math.max(m, Number(k.code) || 0), 0) + 1));
		await upsertKebele({
			code,
			name: newName.trim()
		});
		setNewName("");
		setNewCode("");
		bumpRegistry();
		await reload();
		toast.success(`Added kebele ${code}`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Settings",
				subtitle: "Woreda identity and kebele list stored only on this device"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-border bg-surface p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-sm font-semibold",
					children: "Location"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Region",
							am: AM.region,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: settings.region,
								onChange: (e) => setSettings({
									...settings,
									region: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Zone",
							am: AM.zone,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: settings.zone,
								onChange: (e) => setSettings({
									...settings,
									zone: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Woreda",
							am: AM.woreda,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: settings.woreda,
								onChange: (e) => setSettings({
									...settings,
									woreda: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Region code",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: settings.regionCode,
										onChange: (e) => setSettings({
											...settings,
											regionCode: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Zone code",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: settings.zoneCode,
										onChange: (e) => setSettings({
											...settings,
											zoneCode: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Woreda code",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: settings.woredaCode,
										onChange: (e) => setSettings({
											...settings,
											woredaCode: e.target.value
										})
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: save,
							children: "Save location"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-[24px] border border-border bg-surface p-5 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-1 text-sm font-semibold",
						children: "Kebeles"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-sm text-muted",
						children: "Codes become part of every new household ID."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 grid grid-cols-[80px_1fr_auto] gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Code",
								value: newCode,
								onChange: (e) => setNewCode(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Kebele name",
								value: newName,
								onChange: (e) => setNewName(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: addKebele,
								children: "Add"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: kebeles.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex min-h-12 items-center justify-between gap-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted",
								children: k.code
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 font-medium",
								children: k.name
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm text-danger",
								onClick: async () => {
									try {
										await deleteKebele(k.code);
										bumpRegistry();
										await reload();
									} catch (err) {
										toast.error(err instanceof Error ? err.message : "Could not delete");
									}
								},
								children: "Remove"
							})]
						}, k.code))
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
