import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { a as Trash2, c as Pencil, s as Plus, t as X } from "./_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, t as Dialog$1 } from "./_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { i as cn, n as Route$1 } from "./_ssr/router-b6X6bWYl.mjs";
import { t as Button } from "./_ssr/button-DAHYoAhQ.mjs";
import { A as useDbReady, C as scaleTone, D as updateHousehold, M as useKebeles, N as useRegistryTick, O as updateMember, d as deleteHousehold, g as getHouseholdMembers, h as getHousehold, o as addMember, p as deleteMember, r as PageHeader, s as bumpRegistry, y as memberDisplayCode } from "./_ssr/use-registry-DwO4lW8R.mjs";
import { n as formatDate, t as ageFromDob } from "./_ssr/format-Crs6fxee.mjs";
import { i as emptyMember, n as MemberFields, t as HouseholdFields } from "./_ssr/member-fields-CMf6vECy.mjs";
import { t as Badge } from "./_ssr/badge-DmolU3Bu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-3_jwkq9-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
function DialogContent({ className, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-black/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed inset-x-0 bottom-0 z-50 max-h-[92vh] overflow-y-auto rounded-t-[24px] bg-surface p-5 shadow-card md:inset-auto md:top-1/2 md:left-1/2 md:w-[min(520px,calc(100%-2rem))] md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-[24px]", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "text-lg font-semibold tracking-tight",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "flex size-10 items-center justify-center rounded-[12px] text-muted hover:bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			})]
		}), children]
	})] });
}
function HouseholdDetailPage() {
	const { id } = Route$1.useParams();
	const { ready } = useDbReady();
	const tick = useRegistryTick();
	const kebeles = useKebeles();
	const navigate = useNavigate();
	const [hh, setHh] = (0, import_react.useState)(void 0);
	const [members, setMembers] = (0, import_react.useState)([]);
	const [editingHh, setEditingHh] = (0, import_react.useState)(false);
	const [hhForm, setHhForm] = (0, import_react.useState)(null);
	const [memberForm, setMemberForm] = (0, import_react.useState)(null);
	const [editingMemberId, setEditingMemberId] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		getHousehold(id).then(setHh);
		getHouseholdMembers(id).then(setMembers);
	}, [
		id,
		ready,
		tick
	]);
	if (!ready || hh === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Loading household…"
	});
	if (!hh) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Household not found."
	});
	const openNewMember = () => {
		setEditingMemberId(null);
		setMemberForm(emptyMember("Son"));
	};
	const openEditMember = (m) => {
		setEditingMemberId(m.id);
		setMemberForm({
			name: m.name,
			gender: m.gender,
			dob: {
				day: m.dobDay,
				month: m.dobMonth,
				year: m.dobYear
			},
			relationship: m.relationship || "Other",
			profession: m.profession,
			beneficiaryId: m.beneficiaryId
		});
	};
	const saveHousehold = async () => {
		if (!hhForm) return;
		setBusy(true);
		try {
			await updateHousehold(hh.id, hhForm);
			bumpRegistry();
			setEditingHh(false);
			toast.success("Household updated");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Update failed");
		} finally {
			setBusy(false);
		}
	};
	const saveMember = async () => {
		if (!memberForm || !memberForm.name.trim()) {
			toast.error("Name is required");
			return;
		}
		setBusy(true);
		try {
			if (editingMemberId) await updateMember(editingMemberId, memberForm);
			else await addMember(hh.id, memberForm);
			bumpRegistry();
			setMemberForm(null);
			toast.success(editingMemberId ? "Member updated" : "Member added");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save member");
		} finally {
			setBusy(false);
		}
	};
	const removeMember = async (m) => {
		if (!confirm(`Remove ${m.name}?`)) return;
		try {
			await deleteMember(m.id);
			bumpRegistry();
			toast.success("Member removed");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete");
		}
	};
	const removeHousehold = async () => {
		if (!confirm(`Delete household ${hh.code} and all members? This cannot be undone.`)) return;
		await deleteHousehold(hh.id);
		bumpRegistry();
		toast.success("Household deleted");
		await navigate({ to: "/households" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: hh.headName || "Household",
				subtitle: hh.code,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => {
						setHhForm({
							scheme: hh.scheme,
							kebeleName: hh.kebeleName,
							kebeleCode: hh.kebeleCode,
							gote: hh.gote,
							slidingScale: hh.slidingScale,
							settlement: hh.settlement,
							hasCard: hh.hasCard,
							enroll: {
								day: hh.enrollDay,
								month: hh.enrollMonth,
								year: hh.enrollYear
							}
						});
						setEditingHh(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }), "Edit"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "primary",
						children: hh.kebeleName
					}),
					hh.slidingScale ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: scaleTone(hh.slidingScale),
						children: hh.slidingScale
					}) : null,
					hh.settlement ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: hh.settlement }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: hh.hasCard ? "primary" : "muted",
						children: hh.hasCard ? "ID card" : "No card"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: hh.scheme === "I" ? "Indigent" : "Paying" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-2 gap-3 rounded-[20px] border border-border bg-surface p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "Gote"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium",
						children: hh.gote || "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "Enrolled"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium",
						children: formatDate({
							day: hh.enrollDay,
							month: hh.enrollMonth,
							year: hh.enrollYear
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "Members"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium tabular",
						children: hh.memberCount
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "Kebele code"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-mono font-medium",
						children: hh.kebeleCode
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Members"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: openNewMember,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add member"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 overflow-hidden rounded-[20px] border border-border bg-surface",
				children: members.map((m) => {
					const age = ageFromDob(m.dobYear);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 border-b border-border px-4 py-3 last:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: m.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 font-mono text-xs text-muted",
									children: memberDisplayCode(hh.code, m.beneficiaryId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs text-muted",
									children: [
										m.relationship || "—",
										" · ",
										m.gender || "—",
										age !== null ? ` · ${age} yrs` : "",
										m.profession ? ` · ${m.profession}` : ""
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: () => openEditMember(m),
								"aria-label": "Edit member",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: () => removeMember(m),
								"aria-label": "Delete member",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-danger" })
							})]
						})]
					}, m.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-6 w-full text-danger",
				onClick: removeHousehold,
				children: "Delete household"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: editingHh,
				onOpenChange: setEditingHh,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: "Edit household",
					children: hhForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseholdFields, {
							value: hhForm,
							onChange: setHhForm,
							kebeles
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveHousehold,
							disabled: busy,
							children: "Save changes"
						})]
					}) : null
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!memberForm,
				onOpenChange: (open) => !open && setMemberForm(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					title: editingMemberId ? "Edit member" : "Add member",
					children: memberForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberFields, {
							value: memberForm,
							onChange: setMemberForm,
							lockHead: memberForm.relationship === "Household Head"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: saveMember,
							disabled: busy,
							children: editingMemberId ? "Save member" : "Add member"
						})]
					}) : null
				})
			})
		]
	});
}
//#endregion
export { HouseholdDetailPage as component };
