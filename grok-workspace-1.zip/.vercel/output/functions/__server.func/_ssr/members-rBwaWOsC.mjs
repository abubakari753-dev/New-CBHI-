import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as Search } from "../_libs/lucide-react.mjs";
import { A as useDbReady, n as EmptyState, r as PageHeader, w as searchMembers, y as memberDisplayCode } from "./use-registry-DwO4lW8R.mjs";
import { t as ageFromDob } from "./format-Crs6fxee.mjs";
import { n as Input } from "./input-BZ_a7Ma_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/members-rBwaWOsC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MembersPage() {
	const { ready } = useDbReady();
	const [q, setQ] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const handle = setTimeout(() => {
			searchMembers(q, 250).then(setRows);
		}, 150);
		return () => clearTimeout(handle);
	}, [q, ready]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Opening registry…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Members",
			subtitle: "Search beneficiaries across every household"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-3.5 left-3 size-4 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "Name, ID, relationship",
				className: "pl-9"
			})]
		}),
		!rows ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-10 text-center text-sm text-muted",
			children: "Searching…"
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "No members found",
			body: "Register a household first, or load the 2017 Shinile database from Home."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "overflow-hidden rounded-[20px] border border-border bg-surface",
			children: rows.map((m) => {
				const age = ageFromDob(m.dobYear);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-border last:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/households/$id",
						params: { id: m.householdId },
						className: "block min-h-16 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: m.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 font-mono text-xs text-muted",
								children: memberDisplayCode(m.householdCode, m.beneficiaryId)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									m.relationship || "—",
									" · ",
									m.gender || "—",
									age !== null ? ` · ${age} yrs` : ""
								]
							})
						]
					})
				}, m.id);
			})
		})
	] });
}
//#endregion
export { MembersPage as component };
