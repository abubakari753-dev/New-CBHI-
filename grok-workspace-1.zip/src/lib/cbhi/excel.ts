import { db, ensureDb, toHouseholdRecord, toMemberRecord } from "./db";
import { getSettings } from "./db";
import { padBeneficiary, padKebele } from "./ids";
import { parseLooseInt, yesNo } from "./format";
import type { Gender, HouseholdInput, HouseholdRecord, MemberInput, MemberRecord, Scheme, Settlement, SlidingScale } from "./types";

type Cell = string | number | boolean | null | undefined;

function cellStr(value: Cell): string {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function asGender(value: Cell): Gender {
  const t = cellStr(value).toLowerCase();
  if (t === "female" || t === "f") return "Female";
  if (t === "male" || t === "m") return "Male";
  return "";
}

function asScale(value: Cell): SlidingScale {
  const t = cellStr(value);
  if (t === "Higher" || t === "Middle" || t === "Lower") return t;
  return "";
}

function asSettlement(value: Cell): Settlement {
  const t = cellStr(value);
  if (t === "Rural" || t === "Town") return t;
  return "";
}

function asSchemeFromCode(code: string): Scheme {
  return code.toUpperCase().startsWith("I/") ? "I" : "P";
}

function asBool(value: Cell): boolean {
  const t = cellStr(value).toLowerCase();
  return t === "yes" || t === "y" || t === "true" || t === "1";
}

function headerKey(value: Cell): string {
  return cellStr(value).toLowerCase().replace(/\*/g, "").replace(/\s+/g, " ").trim();
}

type ColMap = Partial<{
  name: number;
  dobDay: number;
  dobMonth: number;
  dobYear: number;
  gender: number;
  householdId: number;
  beneficiaryId: number;
  kebele: number;
  gote: number;
  relationship: number;
  profession: number;
  enrollDay: number;
  enrollMonth: number;
  enrollYear: number;
  sliding: number;
  settlement: number;
  card: number;
  scheme: number;
}>;

function detectColumns(rows: Cell[][]): { map: ColMap; dataStart: number } | null {
  for (let i = 0; i < Math.min(rows.length, 20); i++) {
    const row = rows[i] ?? [];
    const labels = row.map(headerKey);
    const name = labels.findIndex((v) => v.includes("full name") || v === "name");
    const hh = labels.findIndex((v) => v.includes("household cbhi") || v.includes("household id"));
    if (name >= 0 && hh >= 0) {
      const map: ColMap = { name, householdId: hh };
      map.gender = labels.findIndex((v) => v.startsWith("gender"));
      map.beneficiaryId = labels.findIndex((v) => v.includes("beneficiary"));
      map.kebele = labels.findIndex((v) => v.includes("kebele"));
      map.gote = labels.findIndex((v) => v === "gote");
      map.relationship = labels.findIndex((v) => v.includes("relationship"));
      map.profession = labels.findIndex((v) => v.includes("profession"));
      map.sliding = labels.findIndex((v) => v.includes("sliding"));
      map.settlement = labels.findIndex((v) => v.includes("rural") || v.includes("town admin"));
      map.card = labels.findIndex((v) => v.includes("id card"));
      map.scheme = labels.findIndex((v) => v === "scheme");
      map.dobDay = name + 1;
      map.dobMonth = name + 2;
      map.dobYear = name + 3;
      const enroll = labels.findIndex((v) => v.includes("enrollment"));
      if (enroll >= 0) {
        map.enrollDay = enroll;
        map.enrollMonth = enroll + 1;
        map.enrollYear = enroll + 2;
      }
      let dataStart = i + 1;
      while (dataStart < rows.length) {
        const probe = headerKey(rows[dataStart]?.[name]);
        if (probe && !probe.includes("day") && !probe.includes("ቀን") && probe !== "full name") break;
        dataStart += 1;
      }
      return { map, dataStart };
    }
  }
  return null;
}

function col(row: Cell[], index: number | undefined): Cell {
  if (index === undefined || index < 0) return "";
  return row[index];
}

export async function importExcelFile(
  file: File,
  mode: "replace" | "merge",
  onProgress?: (done: number, total: number) => void,
): Promise<{ households: number; members: number }> {
  const XLSX = await import("xlsx");
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const sheetName = wb.SheetNames[0];
  if (!sheetName) throw new Error("The spreadsheet is empty.");
  const sheet = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json<Cell[]>(sheet, { header: 1, defval: "", raw: false }) as Cell[][];
  const detected = detectColumns(rows);
  if (!detected) {
    throw new Error("Could not find CBHI columns (Full Name + Household CBHI Id).");
  }
  const { map, dataStart } = detected;

  type Group = {
    code: string;
    input: HouseholdInput;
    members: MemberInput[];
  };
  const groups = new Map<string, Group>();
  let lastCode = "";

  for (let i = dataStart; i < rows.length; i++) {
    const row = rows[i] ?? [];
    const name = cellStr(col(row, map.name));
    if (!name) continue;
    let code = cellStr(col(row, map.householdId)).toUpperCase();
    if (!code) code = lastCode;
    if (!code) continue;
    lastCode = code;
    let group = groups.get(code);
    if (!group) {
      group = {
        code,
        input: {
          scheme: asSchemeFromCode(code),
          kebeleName: cellStr(col(row, map.kebele)),
          kebeleCode: padKebele(cellStr(col(row, map.kebele)).match(/(\d+)/)?.[1] ?? String(groups.size + 1)),
          gote: cellStr(col(row, map.gote)),
          slidingScale: asScale(col(row, map.sliding)),
          settlement: asSettlement(col(row, map.settlement)),
          hasCard: asBool(col(row, map.card)),
          enroll: {
            day: parseLooseInt(col(row, map.enrollDay)),
            month: parseLooseInt(col(row, map.enrollMonth)),
            year: parseLooseInt(col(row, map.enrollYear)),
          },
        },
        members: [],
      };
      // Prefer explicit kebele code if the kebele cell is a known name we'll fill later
      const kebeleCell = cellStr(col(row, map.kebele));
      group.input.kebeleName = kebeleCell;
      groups.set(code, group);
    } else {
      if (!group.input.kebeleName) group.input.kebeleName = cellStr(col(row, map.kebele));
      if (!group.input.gote) group.input.gote = cellStr(col(row, map.gote));
      if (!group.input.slidingScale) group.input.slidingScale = asScale(col(row, map.sliding));
      if (!group.input.settlement) group.input.settlement = asSettlement(col(row, map.settlement));
    }
    group.members.push({
      name,
      gender: asGender(col(row, map.gender)),
      dob: {
        day: parseLooseInt(col(row, map.dobDay)),
        month: parseLooseInt(col(row, map.dobMonth)),
        year: parseLooseInt(col(row, map.dobYear)),
      },
      relationship: cellStr(col(row, map.relationship)),
      profession: cellStr(col(row, map.profession)),
      beneficiaryId: padBeneficiary(cellStr(col(row, map.beneficiaryId)) || String(group.members.length)),
    });
  }

  await ensureDb();
  const kebeles = await db.kebeles.toArray();
  const kebelesByName = new Map(kebeles.map((k) => [k.name.toLowerCase(), k]));
  const hhRows: HouseholdRecord[] = [];
  const memberRows: MemberRecord[] = [];
  const kebeleAdds: { code: string; name: string }[] = [];
  let nextKebele = kebeles.reduce((m, k) => Math.max(m, Number.parseInt(k.code, 10) || 0), 0);

  for (const group of groups.values()) {
    const known = kebelesByName.get(group.input.kebeleName.toLowerCase());
    if (known) {
      group.input.kebeleCode = known.code;
      group.input.kebeleName = known.name;
    } else if (group.input.kebeleName) {
      nextKebele += 1;
      const code = padKebele(nextKebele);
      kebeleAdds.push({ code, name: group.input.kebeleName });
      kebelesByName.set(group.input.kebeleName.toLowerCase(), { code, name: group.input.kebeleName });
      group.input.kebeleCode = code;
    }
    const head = group.members.find((m) => m.relationship === "Household Head") ?? group.members[0];
    const hh = toHouseholdRecord(
      group.code,
      group.input,
      head?.name ?? "",
      group.members.length,
      group.members.map((m) => m.name),
    );
    hhRows.push(hh);
    for (const m of group.members) {
      memberRows.push(toMemberRecord(hh.id, hh.code, m));
    }
  }

  if (mode === "replace") {
    await db.households.clear();
    await db.members.clear();
  }
  const chunk = 400;
  if (kebeleAdds.length) await db.kebeles.bulkPut(kebeleAdds);
  for (let i = 0; i < hhRows.length; i += chunk) {
    await db.households.bulkPut(hhRows.slice(i, i + chunk));
    onProgress?.(Math.min(i + chunk, hhRows.length), hhRows.length);
  }
  for (let i = 0; i < memberRows.length; i += chunk) {
    await db.members.bulkPut(memberRows.slice(i, i + chunk));
  }
  return { households: hhRows.length, members: memberRows.length };
}

export async function exportExcel(): Promise<Blob> {
  const XLSX = await import("xlsx");
  await ensureDb();
  const settings = await getSettings();
  const households = await db.households.orderBy("code").toArray();
  const members = await db.members.toArray();
  const byHh = new Map<string, typeof members>();
  for (const m of members) {
    const list = byHh.get(m.householdId) ?? [];
    list.push(m);
    byHh.set(m.householdId, list);
  }

  const header = [
    "Full Name",
    "DOB Day",
    "DOB Month",
    "DOB Year",
    "Gender",
    "Household CBHI Id",
    "Beneficiary CBHI Id",
    "Kebele",
    "Gote",
    "Relationship",
    "Profession",
    "Enrollment Day",
    "Enrollment Month",
    "Enrollment Year",
    "Sliding Scale Category",
    "Rural / Town Admin",
    "Has CBHI Id Card",
    "Scheme",
    "Region",
    "Zone",
    "Woreda",
  ];
  const aoa: Cell[][] = [
    ["CBHI Members & Beneficiaries Profile"],
    [],
    ["Region", settings.region, "Zone", settings.zone, "Woreda", settings.woreda],
    [],
    header,
  ];
  for (const hh of households) {
    const list = (byHh.get(hh.id) ?? []).slice().sort((a, b) => a.beneficiaryId.localeCompare(b.beneficiaryId));
    if (list.length === 0) {
      aoa.push([
        hh.headName,
        "",
        "",
        "",
        "",
        hh.code,
        "00",
        hh.kebeleName,
        hh.gote,
        "Household Head",
        "",
        hh.enrollDay,
        hh.enrollMonth,
        hh.enrollYear,
        hh.slidingScale,
        hh.settlement,
        yesNo(hh.hasCard),
        hh.scheme,
        settings.region,
        settings.zone,
        settings.woreda,
      ]);
      continue;
    }
    list.forEach((m, idx) => {
      aoa.push([
        m.name,
        m.dobDay,
        m.dobMonth,
        m.dobYear,
        m.gender,
        idx === 0 ? hh.code : "",
        m.beneficiaryId,
        hh.kebeleName,
        hh.gote,
        m.relationship,
        m.profession,
        idx === 0 ? hh.enrollDay : "",
        idx === 0 ? hh.enrollMonth : "",
        idx === 0 ? hh.enrollYear : "",
        idx === 0 ? hh.slidingScale : "",
        idx === 0 ? hh.settlement : "",
        idx === 0 ? yesNo(hh.hasCard) : "",
        idx === 0 ? hh.scheme : "",
        idx === 0 ? settings.region : "",
        idx === 0 ? settings.zone : "",
        idx === 0 ? settings.woreda : "",
      ]);
    });
  }
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws["!cols"] = header.map((_, i) => ({ wch: i === 0 ? 28 : 16 }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "CBHI Registration Form");
  const out = XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
  return new Blob([out], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
