import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-DAHYoAhQ.mjs";
import { A as useDbReady, M as useKebeles, l as createHousehold, r as PageHeader, s as bumpRegistry } from "./use-registry-DwO4lW8R.mjs";
import { i as emptyMember, n as MemberFields, r as emptyHousehold, t as HouseholdFields } from "./member-fields-CMf6vECy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-D1ZwCIlu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewHouseholdPage() {
	const { ready } = useDbReady();
	const kebeles = useKebeles();
	const navigate = useNavigate();
	const [hh, setHh] = (0, import_react.useState)(emptyHousehold);
	const [head, setHead] = (0, import_react.useState)(emptyMember("Household Head"));
	const [saving, setSaving] = (0, import_react.useState)(false);
	const submit = async (e) => {
		e.preventDefault();
		if (!hh.kebeleCode) {
			toast.error("Select a kebele");
			return;
		}
		if (!head.name.trim()) {
			toast.error("Household head name is required");
			return;
		}
		if (!head.gender) {
			toast.error("Select gender");
			return;
		}
		setSaving(true);
		try {
			const kebele = kebeles.find((k) => k.code === hh.kebeleCode);
			const created = await createHousehold({
				...hh,
				kebeleName: kebele?.name ?? hh.kebeleName
			}, {
				...head,
				relationship: "Household Head"
			});
			bumpRegistry();
			toast.success(`Registered ${created.code}`);
			await navigate({
				to: "/households/$id",
				params: { id: created.id }
			});
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save household");
		} finally {
			setSaving(false);
		}
	};
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Opening registry…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Register household",
				subtitle: "A unique CBHI ID is assigned on save."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[24px] border border-border bg-surface p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-sm font-semibold",
					children: "Household"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseholdFields, {
					value: hh,
					onChange: setHh,
					kebeles
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-[24px] border border-border bg-surface p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 text-sm font-semibold",
					children: "Household head"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberFields, {
					value: head,
					onChange: setHead,
					lockHead: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-5 w-full",
				size: "lg",
				disabled: saving,
				children: saving ? "Saving…" : "Save household"
			})
		]
	});
}
//#endregion
export { NewHouseholdPage as component };
