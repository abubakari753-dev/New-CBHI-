import { DateFields } from "@/components/date-fields";
import { Field, Input, Select } from "@/components/ui/input";
import { AM, SCHEMES, SETTLEMENTS, SLIDING_SCALES } from "@/lib/cbhi/lookups";
import type { HouseholdInput, KebeleRecord } from "@/lib/cbhi/types";

export function HouseholdFields({
  value,
  onChange,
  kebeles,
}: {
  value: HouseholdInput;
  onChange: (next: HouseholdInput) => void;
  kebeles: KebeleRecord[];
}) {
  return (
    <div className="grid gap-4">
      <Field label="Kebele" am={AM.kebele} required>
        <Select
          value={value.kebeleCode}
          onChange={(e) => {
            const kebele = kebeles.find((k) => k.code === e.target.value);
            onChange({
              ...value,
              kebeleCode: e.target.value,
              kebeleName: kebele?.name ?? value.kebeleName,
            });
          }}
        >
          <option value="">Select kebele</option>
          {kebeles.map((k) => (
            <option key={k.code} value={k.code}>
              {k.code} · {k.name}
            </option>
          ))}
        </Select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Gote" am={AM.gote}>
          <Input value={value.gote} onChange={(e) => onChange({ ...value, gote: e.target.value })} placeholder="06" />
        </Field>
        <Field label="Scheme">
          <Select
            value={value.scheme}
            onChange={(e) => onChange({ ...value, scheme: e.target.value as HouseholdInput["scheme"] })}
          >
            {SCHEMES.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Sliding scale" am={AM.sliding}>
          <Select
            value={value.slidingScale}
            onChange={(e) => onChange({ ...value, slidingScale: e.target.value as HouseholdInput["slidingScale"] })}
          >
            <option value="">Select</option>
            {SLIDING_SCALES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Rural / Town" am={AM.settlement}>
          <Select
            value={value.settlement}
            onChange={(e) => onChange({ ...value, settlement: e.target.value as HouseholdInput["settlement"] })}
          >
            <option value="">Select</option>
            {SETTLEMENTS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label="Enrollment date" am={AM.enrollment}>
        <DateFields value={value.enroll} onChange={(enroll) => onChange({ ...value, enroll })} />
      </Field>
      <label className="flex min-h-11 items-center gap-3 rounded-[12px] border border-border bg-surface px-3">
        <input
          type="checkbox"
          checked={value.hasCard}
          onChange={(e) => onChange({ ...value, hasCard: e.target.checked })}
          className="size-4 accent-primary"
        />
        <span className="text-sm">
          Has CBHI ID card <span className="block text-xs text-muted">{AM.hasCard}</span>
        </span>
      </label>
    </div>
  );
}

export const emptyHousehold = (): HouseholdInput => ({
  scheme: "P",
  kebeleName: "",
  kebeleCode: "",
  gote: "",
  slidingScale: "Middle",
  settlement: "Rural",
  hasCard: true,
  enroll: { day: null, month: null, year: null },
});
