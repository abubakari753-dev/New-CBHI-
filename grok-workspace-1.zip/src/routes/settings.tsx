import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { PageHeader } from "@/components/page-header";
import { AM } from "@/lib/cbhi/lookups";
import { getSettings, saveSettings } from "@/lib/cbhi/db";
import { deleteKebele, listKebeles, upsertKebele } from "@/lib/cbhi/queries";
import { bumpRegistry, useDbReady } from "@/hooks/use-registry";
import type { KebeleRecord, RegistrySettings } from "@/lib/cbhi/types";
import { padKebele } from "@/lib/cbhi/ids";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const { ready } = useDbReady();
  const [settings, setSettings] = useState<RegistrySettings | null>(null);
  const [kebeles, setKebeles] = useState<KebeleRecord[]>([]);
  const [newName, setNewName] = useState("");
  const [newCode, setNewCode] = useState("");

  const reload = async () => {
    setSettings(await getSettings());
    setKebeles(await listKebeles());
  };

  useEffect(() => {
    if (ready) reload();
  }, [ready]);

  if (!ready || !settings) {
    return <p className="py-16 text-center text-sm text-muted">Opening registry…</p>;
  }

  const save = async () => {
    await saveSettings(settings);
    bumpRegistry();
    toast.success("Location saved");
  };

  const addKebele = async () => {
    if (!newName.trim()) {
      toast.error("Kebele name is required");
      return;
    }
    const code = padKebele(newCode || String(kebeles.reduce((m, k) => Math.max(m, Number(k.code) || 0), 0) + 1));
    await upsertKebele({ code, name: newName.trim() });
    setNewName("");
    setNewCode("");
    bumpRegistry();
    await reload();
    toast.success(`Added kebele ${code}`);
  };

  return (
    <div className="pb-8">
      <PageHeader title="Settings" subtitle="Woreda identity and kebele list stored only on this device" />

      <section className="rounded-[24px] border border-border bg-surface p-5 shadow-card">
        <h2 className="mb-4 text-sm font-semibold">Location</h2>
        <div className="grid gap-4">
          <Field label="Region" am={AM.region}>
            <Input value={settings.region} onChange={(e) => setSettings({ ...settings, region: e.target.value })} />
          </Field>
          <Field label="Zone" am={AM.zone}>
            <Input value={settings.zone} onChange={(e) => setSettings({ ...settings, zone: e.target.value })} />
          </Field>
          <Field label="Woreda" am={AM.woreda}>
            <Input value={settings.woreda} onChange={(e) => setSettings({ ...settings, woreda: e.target.value })} />
          </Field>
          <div className="grid grid-cols-3 gap-2">
            <Field label="Region code">
              <Input value={settings.regionCode} onChange={(e) => setSettings({ ...settings, regionCode: e.target.value })} />
            </Field>
            <Field label="Zone code">
              <Input value={settings.zoneCode} onChange={(e) => setSettings({ ...settings, zoneCode: e.target.value })} />
            </Field>
            <Field label="Woreda code">
              <Input value={settings.woredaCode} onChange={(e) => setSettings({ ...settings, woredaCode: e.target.value })} />
            </Field>
          </div>
          <Button onClick={save}>Save location</Button>
        </div>
      </section>

      <section className="mt-4 rounded-[24px] border border-border bg-surface p-5 shadow-card">
        <h2 className="mb-1 text-sm font-semibold">Kebeles</h2>
        <p className="mb-4 text-sm text-muted">Codes become part of every new household ID.</p>
        <div className="mb-4 grid grid-cols-[80px_1fr_auto] gap-2">
          <Input placeholder="Code" value={newCode} onChange={(e) => setNewCode(e.target.value)} />
          <Input placeholder="Kebele name" value={newName} onChange={(e) => setNewName(e.target.value)} />
          <Button variant="secondary" onClick={addKebele}>
            Add
          </Button>
        </div>
        <ul className="divide-y divide-border">
          {kebeles.map((k) => (
            <li key={k.code} className="flex min-h-12 items-center justify-between gap-3 py-2">
              <span>
                <span className="font-mono text-xs text-muted">{k.code}</span>
                <span className="ml-2 font-medium">{k.name}</span>
              </span>
              <button
                type="button"
                className="text-sm text-danger"
                onClick={async () => {
                  try {
                    await deleteKebele(k.code);
                    bumpRegistry();
                    await reload();
                  } catch (err) {
                    toast.error(err instanceof Error ? err.message : "Could not delete");
                  }
                }}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
