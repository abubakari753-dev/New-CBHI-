import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-DAHYoAhQ.mjs";
import { A as useDbReady, E as toMemberRecord, F as useStats, T as toHouseholdRecord, _ as getSettings, b as padBeneficiary, c as clearRegistry, i as SHINILE_KEBELES, m as ensureDb, r as PageHeader, s as bumpRegistry, t as DEFAULT_SETTINGS, u as db, x as padKebele } from "./use-registry-DwO4lW8R.mjs";
import { a as yesNo, i as parseLooseInt, r as formatNumber } from "./format-Crs6fxee.mjs";
import { n as loadSeedGzip, t as importSeed } from "./seed-DSE7o0OK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-CXrARUD4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cellStr(value) {
	if (value === null || value === void 0) return "";
	return String(value).trim();
}
function asGender(value) {
	const t = cellStr(value).toLowerCase();
	if (t === "female" || t === "f") return "Female";
	if (t === "male" || t === "m") return "Male";
	return "";
}
function asScale(value) {
	const t = cellStr(value);
	if (t === "Higher" || t === "Middle" || t === "Lower") return t;
	return "";
}
function asSettlement(value) {
	const t = cellStr(value);
	if (t === "Rural" || t === "Town") return t;
	return "";
}
function asSchemeFromCode(code) {
	return code.toUpperCase().startsWith("I/") ? "I" : "P";
}
function asBool(value) {
	const t = cellStr(value).toLowerCase();
	return t === "yes" || t === "y" || t === "true" || t === "1";
}
function headerKey(value) {
	return cellStr(value).toLowerCase().replace(/\*/g, "").replace(/\s+/g, " ").trim();
}
function detectColumns(rows) {
	for (let i = 0; i < Math.min(rows.length, 20); i++) {
		const labels = (rows[i] ?? []).map(headerKey);
		const name = labels.findIndex((v) => v.includes("full name") || v === "name");
		const hh = labels.findIndex((v) => v.includes("household cbhi") || v.includes("household id"));
		if (name >= 0 && hh >= 0) {
			const map = {
				name,
				householdId: hh
			};
			map.gender = labels.findIndex((v) => v.startsWith("gender"));
			map.beneficiaryId = labels.findIndex((v) => v.includes("beneficiary"));
			map.kebele = labels.findIndex((v) => v.includes("kebele"));
			map.gote = labels.findIndex((v) => v === "gote");
			map.relationship = labels.findIndex((v) => v.includes("relationship"));
			map.profession = labels.findIndex((v) => v.includes("profession"));
			map.sliding = labels.findIndex((v) => v.includes("sliding"));
			map.settlement = labels.findIndex((v) => v.includes("rural") || v.includes("town admin"));
			map.card = labels.findIndex((v) => v.includes("id card"));
			map.scheme = labels.findIndex((v) => v === "scheme");
			map.dobDay = name + 1;
			map.dobMonth = name + 2;
			map.dobYear = name + 3;
			const enroll = labels.findIndex((v) => v.includes("enrollment"));
			if (enroll >= 0) {
				map.enrollDay = enroll;
				map.enrollMonth = enroll + 1;
				map.enrollYear = enroll + 2;
			}
			let dataStart = i + 1;
			while (dataStart < rows.length) {
				const probe = headerKey(rows[dataStart]?.[name]);
				if (probe && !probe.includes("day") && !probe.includes("ቀን") && probe !== "full name") break;
				dataStart += 1;
			}
			return {
				map,
				dataStart
			};
		}
	}
	return null;
}
function col(row, index) {
	if (index === void 0 || index < 0) return "";
	return row[index];
}
async function importExcelFile(file, mode, onProgress) {
	const XLSX = await import("../_libs/xlsx.mjs").then((n) => n.t);
	const buf = await file.arrayBuffer();
	const wb = XLSX.read(buf, { type: "array" });
	const sheetName = wb.SheetNames[0];
	if (!sheetName) throw new Error("The spreadsheet is empty.");
	const sheet = wb.Sheets[sheetName];
	const rows = XLSX.utils.sheet_to_json(sheet, {
		header: 1,
		defval: "",
		raw: false
	});
	const detected = detectColumns(rows);
	if (!detected) throw new Error("Could not find CBHI columns (Full Name + Household CBHI Id).");
	const { map, dataStart } = detected;
	const groups = /* @__PURE__ */ new Map();
	let lastCode = "";
	for (let i = dataStart; i < rows.length; i++) {
		const row = rows[i] ?? [];
		const name = cellStr(col(row, map.name));
		if (!name) continue;
		let code = cellStr(col(row, map.householdId)).toUpperCase();
		if (!code) code = lastCode;
		if (!code) continue;
		lastCode = code;
		let group = groups.get(code);
		if (!group) {
			group = {
				code,
				input: {
					scheme: asSchemeFromCode(code),
					kebeleName: cellStr(col(row, map.kebele)),
					kebeleCode: padKebele(cellStr(col(row, map.kebele)).match(/(\d+)/)?.[1] ?? String(groups.size + 1)),
					gote: cellStr(col(row, map.gote)),
					slidingScale: asScale(col(row, map.sliding)),
					settlement: asSettlement(col(row, map.settlement)),
					hasCard: asBool(col(row, map.card)),
					enroll: {
						day: parseLooseInt(col(row, map.enrollDay)),
						month: parseLooseInt(col(row, map.enrollMonth)),
						year: parseLooseInt(col(row, map.enrollYear))
					}
				},
				members: []
			};
			const kebeleCell = cellStr(col(row, map.kebele));
			group.input.kebeleName = kebeleCell;
			groups.set(code, group);
		} else {
			if (!group.input.kebeleName) group.input.kebeleName = cellStr(col(row, map.kebele));
			if (!group.input.gote) group.input.gote = cellStr(col(row, map.gote));
			if (!group.input.slidingScale) group.input.slidingScale = asScale(col(row, map.sliding));
			if (!group.input.settlement) group.input.settlement = asSettlement(col(row, map.settlement));
		}
		group.members.push({
			name,
			gender: asGender(col(row, map.gender)),
			dob: {
				day: parseLooseInt(col(row, map.dobDay)),
				month: parseLooseInt(col(row, map.dobMonth)),
				year: parseLooseInt(col(row, map.dobYear))
			},
			relationship: cellStr(col(row, map.relationship)),
			profession: cellStr(col(row, map.profession)),
			beneficiaryId: padBeneficiary(cellStr(col(row, map.beneficiaryId)) || String(group.members.length))
		});
	}
	await ensureDb();
	const kebeles = await db.kebeles.toArray();
	const kebelesByName = new Map(kebeles.map((k) => [k.name.toLowerCase(), k]));
	const hhRows = [];
	const memberRows = [];
	const kebeleAdds = [];
	let nextKebele = kebeles.reduce((m, k) => Math.max(m, Number.parseInt(k.code, 10) || 0), 0);
	for (const group of groups.values()) {
		const known = kebelesByName.get(group.input.kebeleName.toLowerCase());
		if (known) {
			group.input.kebeleCode = known.code;
			group.input.kebeleName = known.name;
		} else if (group.input.kebeleName) {
			nextKebele += 1;
			const code = padKebele(nextKebele);
			kebeleAdds.push({
				code,
				name: group.input.kebeleName
			});
			kebelesByName.set(group.input.kebeleName.toLowerCase(), {
				code,
				name: group.input.kebeleName
			});
			group.input.kebeleCode = code;
		}
		const head = group.members.find((m) => m.relationship === "Household Head") ?? group.members[0];
		const hh = toHouseholdRecord(group.code, group.input, head?.name ?? "", group.members.length, group.members.map((m) => m.name));
		hhRows.push(hh);
		for (const m of group.members) memberRows.push(toMemberRecord(hh.id, hh.code, m));
	}
	if (mode === "replace") {
		await db.households.clear();
		await db.members.clear();
	}
	const chunk = 400;
	if (kebeleAdds.length) await db.kebeles.bulkPut(kebeleAdds);
	for (let i = 0; i < hhRows.length; i += chunk) {
		await db.households.bulkPut(hhRows.slice(i, i + chunk));
		onProgress?.(Math.min(i + chunk, hhRows.length), hhRows.length);
	}
	for (let i = 0; i < memberRows.length; i += chunk) await db.members.bulkPut(memberRows.slice(i, i + chunk));
	return {
		households: hhRows.length,
		members: memberRows.length
	};
}
async function exportExcel() {
	const XLSX = await import("../_libs/xlsx.mjs").then((n) => n.t);
	await ensureDb();
	const settings = await getSettings();
	const households = await db.households.orderBy("code").toArray();
	const members = await db.members.toArray();
	const byHh = /* @__PURE__ */ new Map();
	for (const m of members) {
		const list = byHh.get(m.householdId) ?? [];
		list.push(m);
		byHh.set(m.householdId, list);
	}
	const header = [
		"Full Name",
		"DOB Day",
		"DOB Month",
		"DOB Year",
		"Gender",
		"Household CBHI Id",
		"Beneficiary CBHI Id",
		"Kebele",
		"Gote",
		"Relationship",
		"Profession",
		"Enrollment Day",
		"Enrollment Month",
		"Enrollment Year",
		"Sliding Scale Category",
		"Rural / Town Admin",
		"Has CBHI Id Card",
		"Scheme",
		"Region",
		"Zone",
		"Woreda"
	];
	const aoa = [
		["CBHI Members & Beneficiaries Profile"],
		[],
		[
			"Region",
			settings.region,
			"Zone",
			settings.zone,
			"Woreda",
			settings.woreda
		],
		[],
		header
	];
	for (const hh of households) {
		const list = (byHh.get(hh.id) ?? []).slice().sort((a, b) => a.beneficiaryId.localeCompare(b.beneficiaryId));
		if (list.length === 0) {
			aoa.push([
				hh.headName,
				"",
				"",
				"",
				"",
				hh.code,
				"00",
				hh.kebeleName,
				hh.gote,
				"Household Head",
				"",
				hh.enrollDay,
				hh.enrollMonth,
				hh.enrollYear,
				hh.slidingScale,
				hh.settlement,
				yesNo(hh.hasCard),
				hh.scheme,
				settings.region,
				settings.zone,
				settings.woreda
			]);
			continue;
		}
		list.forEach((m, idx) => {
			aoa.push([
				m.name,
				m.dobDay,
				m.dobMonth,
				m.dobYear,
				m.gender,
				idx === 0 ? hh.code : "",
				m.beneficiaryId,
				hh.kebeleName,
				hh.gote,
				m.relationship,
				m.profession,
				idx === 0 ? hh.enrollDay : "",
				idx === 0 ? hh.enrollMonth : "",
				idx === 0 ? hh.enrollYear : "",
				idx === 0 ? hh.slidingScale : "",
				idx === 0 ? hh.settlement : "",
				idx === 0 ? yesNo(hh.hasCard) : "",
				idx === 0 ? hh.scheme : "",
				idx === 0 ? settings.region : "",
				idx === 0 ? settings.zone : "",
				idx === 0 ? settings.woreda : ""
			]);
		});
	}
	const ws = XLSX.utils.aoa_to_sheet(aoa);
	ws["!cols"] = header.map((_, i) => ({ wch: i === 0 ? 28 : 16 }));
	const wb = XLSX.utils.book_new();
	XLSX.utils.book_append_sheet(wb, ws, "CBHI Registration Form");
	const out = XLSX.write(wb, {
		type: "array",
		bookType: "xlsx"
	});
	return new Blob([out], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 1500);
}
async function createBackup() {
	await ensureDb();
	const [settingsRow, kebeles, households, members] = await Promise.all([
		db.meta.get("settings"),
		db.kebeles.toArray(),
		db.households.toArray(),
		db.members.toArray()
	]);
	return {
		version: 1,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		settings: settingsRow?.value ?? DEFAULT_SETTINGS,
		kebeles,
		households,
		members
	};
}
async function downloadBackup() {
	const backup = await createBackup();
	downloadBlob(new Blob([JSON.stringify(backup)], { type: "application/json" }), `cbhi-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`);
}
async function restoreBackup(file) {
	const text = await file.text();
	const data = JSON.parse(text);
	if (!data || data.version !== 1 || !Array.isArray(data.households) || !Array.isArray(data.members)) throw new Error("This file is not a CBHI Registry backup.");
	await ensureDb();
	await db.transaction("rw", db.households, db.members, db.kebeles, db.meta, async () => {
		await db.households.clear();
		await db.members.clear();
		await db.kebeles.clear();
		if (data.settings) await db.meta.put({
			key: "settings",
			value: data.settings
		});
		await db.kebeles.bulkPut(data.kebeles?.length ? data.kebeles : SHINILE_KEBELES);
		const chunk = 400;
		for (let i = 0; i < data.households.length; i += chunk) await db.households.bulkPut(data.households.slice(i, i + chunk));
		for (let i = 0; i < data.members.length; i += chunk) await db.members.bulkPut(data.members.slice(i, i + chunk));
	});
	return {
		households: data.households.length,
		members: data.members.length
	};
}
function DataPage() {
	const { ready } = useDbReady();
	const stats = useStats();
	const excelRef = (0, import_react.useRef)(null);
	const backupRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(null);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: "Opening registry…"
	});
	const run = async (label, fn) => {
		setBusy(label);
		try {
			await fn();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Action failed");
		} finally {
			setBusy(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Data",
				subtitle: stats ? `${formatNumber(stats.households)} households · ${formatNumber(stats.members)} members on this device` : "Local IndexedDB store"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Excel",
				body: "Import the original CBHI registration workbook, or export a clean sheet Excel can open.",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: excelRef,
					type: "file",
					accept: ".xlsx,.xls",
					className: "hidden",
					onChange: (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						if (!file) return;
						run("import", async () => {
							const result = await importExcelFile(file, "merge");
							bumpRegistry();
							toast.success(`Imported ${result.households.toLocaleString()} households`);
						});
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !!busy,
						onClick: () => excelRef.current?.click(),
						children: busy === "import" ? "Importing…" : "Import Excel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !!busy,
						onClick: () => run("export", async () => {
							downloadBlob(await exportExcel(), `cbhi-export-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.xlsx`);
							toast.success("Excel downloaded");
						}),
						children: busy === "export" ? "Exporting…" : "Export Excel"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Backup",
				body: "Full JSON snapshot of households, members, kebeles, and settings. Restore replaces the local database.",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: backupRef,
					type: "file",
					accept: "application/json,.json",
					className: "hidden",
					onChange: (e) => {
						const file = e.target.files?.[0];
						e.target.value = "";
						if (!file) return;
						run("restore", async () => {
							const result = await restoreBackup(file);
							bumpRegistry();
							toast.success(`Restored ${result.households.toLocaleString()} households`);
						});
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !!busy,
						onClick: () => run("backup", async () => {
							await downloadBackup();
							toast.success("Backup downloaded");
						}),
						children: "Download backup"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !!busy,
						onClick: () => backupRef.current?.click(),
						children: busy === "restore" ? "Restoring…" : "Restore backup"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "2017 Shinile database",
				body: "Load the attached woreda census into this phone. This replaces current households.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !!busy,
					onClick: () => run("seed", async () => {
						if (!confirm("Replace the current registry with the 2017 Shinile database?")) return;
						const seed = await loadSeedGzip();
						const result = await importSeed(seed);
						bumpRegistry();
						toast.success(`Loaded ${result.households.toLocaleString()} households`);
					}),
					children: busy === "seed" ? "Loading…" : "Load 2017 Shinile data"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Install on Android",
				body: "This registry is a standalone app. In Chrome, open the browser menu and choose Add to Home screen or Install app. After that it opens full-screen, stores data on the phone, and works without a network.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/?install=1",
						children: "Installation guide"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Danger zone",
				body: "Clears households and members on this device. Kebeles and location settings are kept.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					disabled: !!busy,
					onClick: () => run("clear", async () => {
						if (!confirm("Delete every household and member on this device?")) return;
						await clearRegistry();
						bumpRegistry();
						toast.success("Registry cleared");
					}),
					children: "Clear all records"
				})
			})
		]
	});
}
function Section({ title, body, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-4 rounded-[24px] border border-border bg-surface p-5 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 mb-4 text-sm text-muted",
				children: body
			}),
			children
		]
	});
}
//#endregion
export { DataPage as component };
