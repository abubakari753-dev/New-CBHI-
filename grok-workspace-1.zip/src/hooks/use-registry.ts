import { useCallback, useEffect, useState } from "react";
import { ensureDb, getSettings } from "@/lib/cbhi/db";
import { getStats, listHouseholds, listKebeles } from "@/lib/cbhi/queries";
import type { HouseholdFilters, HouseholdRecord, KebeleRecord, RegistrySettings, RegistryStats } from "@/lib/cbhi/types";

let revision = 0;
const listeners = new Set<() => void>();

export function bumpRegistry() {
  revision += 1;
  listeners.forEach((fn) => fn());
}

export function useRegistryTick() {
  const [tick, setTick] = useState(revision);
  useEffect(() => {
    const fn = () => setTick(revision);
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }, []);
  return tick;
}

export function useDbReady() {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    ensureDb()
      .then(() => {
        if (!cancelled) setReady(true);
      })
      .catch((err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Database failed to open");
      });
    return () => {
      cancelled = true;
    };
  }, []);
  return { ready, error };
}

export function useSettings() {
  const tick = useRegistryTick();
  const [settings, setSettings] = useState<RegistrySettings | null>(null);
  useEffect(() => {
    getSettings().then(setSettings);
  }, [tick]);
  return settings;
}

export function useStats() {
  const tick = useRegistryTick();
  const [stats, setStats] = useState<RegistryStats | null>(null);
  useEffect(() => {
    getStats().then(setStats);
  }, [tick]);
  return stats;
}

export function useKebeles() {
  const tick = useRegistryTick();
  const [kebeles, setKebeles] = useState<KebeleRecord[]>([]);
  useEffect(() => {
    listKebeles().then(setKebeles);
  }, [tick]);
  return kebeles;
}

export function useHouseholdList(filters: HouseholdFilters) {
  const tick = useRegistryTick();
  const [rows, setRows] = useState<HouseholdRecord[] | null>(null);
  const reload = useCallback(() => {
    setRows(null);
    listHouseholds(filters).then(setRows);
  }, [filters.q, filters.kebeleCode, filters.slidingScale, filters.settlement, filters.scheme, tick]);
  useEffect(() => {
    let cancelled = false;
    listHouseholds(filters).then((data) => {
      if (!cancelled) setRows(data);
    });
    return () => {
      cancelled = true;
    };
  }, [reload]);
  return { rows, reload };
}
