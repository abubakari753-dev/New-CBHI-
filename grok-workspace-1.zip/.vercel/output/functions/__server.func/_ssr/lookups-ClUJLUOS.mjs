//#region node_modules/.nitro/vite/services/ssr/assets/lookups-ClUJLUOS.js
var GENDERS = ["Male", "Female"];
var RELATIONSHIPS = [
	"Household Head",
	"Parent",
	"Husband",
	"Wife",
	"Son",
	"Daughter",
	"Other"
];
var PROFESSIONS = [
	"Farmer",
	"Pastoralist",
	"Merchant",
	"Job Seeker",
	"Housewife",
	"Stay at home Husband",
	"Daily Laborer",
	"Student",
	"Disabled",
	"Other"
];
var SLIDING_SCALES = [
	"Higher",
	"Middle",
	"Lower"
];
var SETTLEMENTS = ["Rural", "Town"];
var SCHEMES = [{
	value: "P",
	label: "Paying (P)"
}, {
	value: "I",
	label: "Indigent (I)"
}];
var AM = {
	app: "የጤና መድን መዝገብ",
	fullName: "ሙሉ ስም",
	dob: "የትውልድ ቀን",
	gender: "ፆታ",
	householdId: "የማአጤመ ቁጥር",
	beneficiaryId: "የአባሉ መለያ ቁጥር",
	kebele: "ቀበሌ",
	gote: "ጎጥ",
	relationship: "የአባሉ ዝምድና",
	profession: "የስራ ዘርፍ",
	enrollment: "የአባልነት ምዝገባ ቀን",
	sliding: "የክፍያ ደረጃ",
	settlement: "ገጠር / ከተማ",
	hasCard: "የማአጤመ መታወቂያ አለው?",
	region: "ክልል",
	zone: "ዞን",
	woreda: "ወረዳ",
	day: "ቀን",
	month: "ወር",
	year: "ዓ/ም"
};
//#endregion
export { SCHEMES as a, RELATIONSHIPS as i, GENDERS as n, SETTLEMENTS as o, PROFESSIONS as r, SLIDING_SCALES as s, AM as t };
