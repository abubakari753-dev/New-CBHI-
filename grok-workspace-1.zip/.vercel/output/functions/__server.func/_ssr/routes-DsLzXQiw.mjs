import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-DAHYoAhQ.mjs";
import { A as useDbReady, F as useStats, P as useSettings, a as StatCard, n as EmptyState, r as PageHeader, s as bumpRegistry } from "./use-registry-DwO4lW8R.mjs";
import { r as formatNumber } from "./format-Crs6fxee.mjs";
import { n as loadSeedGzip, t as importSeed } from "./seed-DSE7o0OK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DsLzXQiw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	const { ready, error } = useDbReady();
	const stats = useStats();
	const settings = useSettings();
	const [seeding, setSeeding] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)("");
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted",
		children: error ?? "Opening local registry…"
	});
	const loadSeed = async () => {
		setSeeding(true);
		try {
			const seed = await loadSeedGzip();
			const result = await importSeed(seed, (done, total) => {
				setProgress(`${done.toLocaleString()} / ${total.toLocaleString()} households`);
			});
			bumpRegistry();
			toast.success(`Loaded ${result.households.toLocaleString()} households`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load seed data");
		} finally {
			setSeeding(false);
			setProgress("");
		}
	};
	const empty = (stats?.households ?? 0) === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: settings ? settings.woreda : "CBHI Registry",
		subtitle: settings ? `${settings.region} · ${settings.zone} · codes ${settings.regionCode}/${settings.zoneCode}/${settings.woredaCode}` : "Community-Based Health Insurance",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/households/new",
				children: "Register"
			})
		})
	}), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "No households on this device yet",
		body: "Register families in the field, or load the 2017 Shinile woreda database (6,859 households, 25,261 members) into the local store.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: loadSeed,
					disabled: seeding,
					children: seeding ? "Loading…" : "Load 2017 Shinile database"
				}),
				progress ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: progress
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/households/new",
						children: "Start with a new household"
					})
				})
			]
		})
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Households",
					value: formatNumber(stats?.households ?? 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Members",
					value: formatNumber(stats?.members ?? 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Kebeles",
					value: formatNumber(stats?.kebeles ?? 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "With ID card",
					value: formatNumber(stats?.withCard ?? 0)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-[24px] border border-border bg-surface p-5 shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold",
				children: "Sliding scale"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-3",
				children: [
					"Higher",
					"Middle",
					"Lower"
				].map((key) => {
					const count = stats?.byScale[key] ?? 0;
					const total = stats?.households || 1;
					const pct = Math.round(count / total * 100);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: key }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular text-muted",
							children: [
								formatNumber(count),
								" · ",
								pct,
								"%"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary",
							style: { width: `${pct}%` }
						})
					})] }, key);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-[24px] border border-border bg-surface p-5 shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Kebeles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/settings",
					className: "text-sm font-medium text-primary",
					children: "Manage"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: (stats?.byKebele ?? []).slice(0, 8).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/households",
					search: { kebele: k.code },
					className: "flex min-h-12 items-center justify-between py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: k.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-xs text-muted",
						children: k.code
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular text-sm text-muted",
						children: formatNumber(k.count)
					})]
				}) }, k.code))
			})]
		})
	] })] });
}
//#endregion
export { HomePage as component };
