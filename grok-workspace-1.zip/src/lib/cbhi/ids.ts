import type { Scheme } from "./types";

export function codeToId(code: string): string {
  return code.trim().toUpperCase().replaceAll("/", "-");
}

export function idToCode(id: string): string {
  return id.trim().toUpperCase().replaceAll("-", "/");
}

export function memberKey(householdId: string, beneficiaryId: string): string {
  return `${householdId}:${padBeneficiary(beneficiaryId)}`;
}

export function memberDisplayCode(householdCode: string, beneficiaryId: string): string {
  return `${householdCode.toUpperCase()}-${padBeneficiary(beneficiaryId)}`;
}

export function padBeneficiary(value: string | number): string {
  const n = String(value ?? "").replace(/\D/g, "");
  if (!n) return "00";
  return n.padStart(2, "0");
}

export function padKebele(value: string | number): string {
  const n = String(value ?? "").replace(/\D/g, "");
  if (!n) return "01";
  return n.padStart(2, "0");
}

export function padSeq(n: number): string {
  if (n < 0) n = 0;
  if (n > 9999) return String(n).padStart(5, "0");
  return String(n).padStart(4, "0");
}

export function buildHouseholdCode(opts: {
  scheme: Scheme;
  regionCode: string;
  zoneCode: string;
  woredaCode: string;
  kebeleCode: string;
  seq: number;
}): string {
  const scheme = opts.scheme === "I" ? "I" : "P";
  const region = String(opts.regionCode).replace(/\D/g, "").padStart(2, "0") || "00";
  const zone = String(opts.zoneCode).replace(/\D/g, "").padStart(2, "0") || "00";
  const woreda = String(opts.woredaCode).replace(/\D/g, "").padStart(2, "0") || "00";
  const kebele = padKebele(opts.kebeleCode);
  return `${scheme}/${region}/${zone}/${woreda}/${kebele}/${padSeq(opts.seq)}`;
}

export function parseHouseholdCode(code: string): {
  scheme: Scheme;
  regionCode: string;
  zoneCode: string;
  woredaCode: string;
  kebeleCode: string;
  seq: number;
} | null {
  const parts = code.trim().toUpperCase().split("/").filter(Boolean);
  if (parts.length < 6) return null;
  const scheme: Scheme = parts[0] === "I" ? "I" : "P";
  const seq = Number.parseInt(parts[5] ?? "0", 10);
  return {
    scheme,
    regionCode: (parts[1] ?? "00").padStart(2, "0"),
    zoneCode: (parts[2] ?? "00").padStart(2, "0"),
    woredaCode: (parts[3] ?? "00").padStart(2, "0"),
    kebeleCode: (parts[4] ?? "00").padStart(2, "0"),
    seq: Number.isFinite(seq) ? seq : 0,
  };
}

export function nextSeq(codes: string[], prefix: string): number {
  const needle = prefix.toUpperCase();
  let max = 0;
  for (const code of codes) {
    const value = code.toUpperCase();
    if (!value.startsWith(needle)) continue;
    const tail = value.slice(needle.length);
    const n = Number.parseInt(tail, 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return max + 1;
}

export function searchBlob(...parts: Array<string | null | undefined>): string {
  return parts
    .filter(Boolean)
    .join(" ")
    .toLowerCase()
    .replaceAll("/", " ")
    .replaceAll("-", " ")
    .replace(/\s+/g, " ")
    .trim();
}
